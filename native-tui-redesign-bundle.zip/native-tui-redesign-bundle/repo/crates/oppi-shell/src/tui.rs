use super::*;

const SPINNER_FRAMES: [&str; 10] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];

pub(super) fn retained_tui_interactive_loop(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
) -> Result<(), String> {
    let _guard = TuiTerminalGuard::enter()?;
    session.terminal_ui_active = true;
    session.print_text(
        "OPPi native TUI ready — /settings opens settings; Ctrl+L selects model; Enter submits; Shift+Enter newline; Ctrl+C twice exits.",
        false,
    )?;
    let mut state = NativeTuiState::default();
    let mut renderer = DifferentialRenderer::default();
    let mut running = true;
    while running {
        let (width, height) = terminal::size().unwrap_or((100, 30));
        state.spinner_index = state.spinner_index.wrapping_add(1);
        session.sync_ui_docks();
        let frame =
            render_native_tui_frame(session, provider, &state, width as usize, height as usize);
        renderer.render(&frame)?;

        if event::poll(Duration::from_millis(40))
            .map_err(|error| format!("poll terminal input: {error}"))?
        {
            match event::read().map_err(|error| format!("read terminal input: {error}"))? {
                CrosstermEvent::Key(key) if key.kind != KeyEventKind::Release => {
                    running = handle_tui_key(session, provider, &mut state, key)?;
                }
                CrosstermEvent::Resize(_, _) => renderer.invalidate(),
                _ => {}
            }
        }

        if let Some(outcome) = session.poll_turn_events_silent()? {
            if matches!(outcome, TurnOutcome::Completed) {
                session.start_next_queued_follow_up(provider, false)?;
            }
        } else if !session.is_turn_running() && !session.has_pending_pause() {
            session.start_next_queued_follow_up(provider, false)?;
        }
    }
    session.terminal_ui_active = false;
    Ok(())
}

#[derive(Debug, Default)]
struct NativeTuiState {
    editor: LineEditor,
    overlay: Option<TuiOverlay>,
    spinner_index: usize,
    slash_selected: usize,
    slash_keyboard_mode: bool,
    slash_palette_suppressed: bool,
}

impl NativeTuiState {
    fn reset_slash_navigation(&mut self) {
        self.slash_selected = 0;
        self.slash_keyboard_mode = false;
        self.slash_palette_suppressed = false;
    }

    fn current_slash_palette(&self, session: &ShellSession) -> Option<SlashPalette> {
        if self.slash_palette_suppressed {
            return None;
        }
        slash_palette_for_buffer_with_session(
            self.editor.buffer_preview(),
            self.slash_selected,
            session,
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum TuiOverlay {
    Settings {
        selected: usize,
    },
    SettingsPanel {
        panel: SettingsSubpanel,
        selected: usize,
        items: Vec<SettingsPanelItem>,
    },
    Sessions {
        selected: usize,
        query: String,
        items: Vec<SessionPickerItem>,
    },
    Models {
        selected: usize,
        query: String,
        items: Vec<ModelPickerItem>,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum SettingsSubpanel {
    Theme,
    Permissions,
    Provider,
    Login,
    LoginSubscription,
    LoginApi,
    LoginClaude,
    Memory,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct SettingsPanelItem {
    label: String,
    value: String,
    detail: String,
    current: bool,
    action: SettingsPanelAction,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum SettingsPanelAction {
    Command(String),
    EditCommand(String),
    OpenPanel(SettingsSubpanel),
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct SessionPickerItem {
    id: String,
    title: String,
    status: String,
    cwd: String,
    forked_from: Option<String>,
    current: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ModelPickerItem {
    label: String,
    detail: String,
    action: ModelPickerAction,
    current: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum ModelPickerAction {
    SelectSession(String),
    SelectRole { role: String, model: String },
    ClearRole { role: String },
}

struct TuiTerminalGuard;

impl TuiTerminalGuard {
    fn enter() -> Result<Self, String> {
        terminal::enable_raw_mode()
            .map_err(|error| format!("enable raw terminal mode: {error}"))?;
        print!("\x1b[?25l");
        io::stdout()
            .flush()
            .map_err(|error| format!("flush terminal setup: {error}"))?;
        Ok(Self)
    }
}

impl Drop for TuiTerminalGuard {
    fn drop(&mut self) {
        print!("\x1b[?25h\x1b[0m\r\n");
        let _ = io::stdout().flush();
        let _ = terminal::disable_raw_mode();
    }
}

#[derive(Debug, Default)]
struct DifferentialRenderer {
    previous: Vec<String>,
    previous_width: usize,
}

impl DifferentialRenderer {
    fn invalidate(&mut self) {
        self.previous.clear();
        self.previous_width = 0;
    }

    fn render(&mut self, lines: &[String]) -> Result<(), String> {
        let width = lines
            .iter()
            .map(|line| tui_visible_width(line))
            .max()
            .unwrap_or(0);
        let mut out = String::new();
        out.push_str("\x1b[?2026h");
        if self.previous.is_empty() || self.previous_width != width {
            if !self.previous.is_empty() {
                out.push('\r');
                if self.previous.len() > 1 {
                    out.push_str(&format!("\x1b[{}A", self.previous.len() - 1));
                }
                out.push_str("\x1b[J");
            }
            for (index, line) in lines.iter().enumerate() {
                if index > 0 {
                    out.push_str("\r\n");
                }
                out.push_str("\x1b[2K");
                out.push_str(line);
            }
        } else {
            let max_len = self.previous.len().max(lines.len());
            let first_changed =
                (0..max_len).find(|index| self.previous.get(*index) != lines.get(*index));
            if let Some(first) = first_changed {
                out.push('\r');
                if self.previous.len() > 1 {
                    out.push_str(&format!("\x1b[{}A", self.previous.len() - 1));
                }
                if first > 0 {
                    out.push_str(&format!("\x1b[{}B", first));
                }
                out.push_str("\x1b[J");
                for (offset, line) in lines.iter().enumerate().skip(first) {
                    if offset > first {
                        out.push_str("\r\n");
                    }
                    out.push_str("\x1b[2K");
                    out.push_str(line);
                }
            }
        }
        out.push_str("\x1b[?2026l");
        print!("{out}");
        io::stdout()
            .flush()
            .map_err(|error| format!("flush TUI frame: {error}"))?;
        self.previous = lines.to_vec();
        self.previous_width = width;
        Ok(())
    }
}

fn handle_tui_key(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    key: event::KeyEvent,
) -> Result<bool, String> {
    if state.overlay.is_some() {
        return handle_tui_overlay_key(session, provider, state, key);
    }
    if handle_tui_app_key(session, provider, state, key)? {
        return Ok(true);
    }
    let Some(input) = editor_input_from_key(key) else {
        return Ok(true);
    };
    if let Some(keep_running) = handle_tui_slash_palette_input(session, provider, state, &input)? {
        return Ok(keep_running);
    }
    let action = state.editor.handle(input.clone());
    if matches!(
        input,
        EditorInput::Text(_) | EditorInput::Backspace | EditorInput::Delete
    ) {
        state.reset_slash_navigation();
    }
    handle_tui_editor_action(session, provider, state, action)
}

fn handle_tui_app_key(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    key: event::KeyEvent,
) -> Result<bool, String> {
    let modifiers = key.modifiers;
    match key.code {
        KeyCode::Char('l') if modifiers.contains(KeyModifiers::CONTROL) => {
            open_models_overlay(session, provider, state)?;
            Ok(true)
        }
        KeyCode::Char('p')
            if modifiers.contains(KeyModifiers::CONTROL)
                && modifiers.contains(KeyModifiers::SHIFT) =>
        {
            cycle_session_model(session, provider, true)?;
            Ok(true)
        }
        KeyCode::Char('P') if modifiers.contains(KeyModifiers::CONTROL) => {
            cycle_session_model(session, provider, true)?;
            Ok(true)
        }
        KeyCode::Char('p') if modifiers.contains(KeyModifiers::CONTROL) => {
            cycle_session_model(session, provider, false)?;
            Ok(true)
        }
        KeyCode::BackTab => {
            cycle_reasoning_effort(session, provider)?;
            Ok(true)
        }
        _ => Ok(false),
    }
}

fn handle_tui_slash_palette_input(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    input: &EditorInput,
) -> Result<Option<bool>, String> {
    let buffer = state.editor.buffer_preview().to_string();
    let Some(palette) = state.current_slash_palette(session) else {
        if !buffer.trim_start().starts_with('/') {
            state.reset_slash_navigation();
        }
        return Ok(None);
    };
    state.slash_selected = palette.selected;
    let count = palette.items.len();
    match input {
        EditorInput::Up => {
            state.slash_selected = state.slash_selected.saturating_sub(1);
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::Down => {
            state.slash_selected = (state.slash_selected + 1).min(count.saturating_sub(1));
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::PageUp => {
            state.slash_selected = state.slash_selected.saturating_sub(8);
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::PageDown => {
            state.slash_selected = (state.slash_selected + 8).min(count.saturating_sub(1));
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::Home => {
            state.slash_selected = 0;
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::End => {
            state.slash_selected = count.saturating_sub(1);
            state.slash_keyboard_mode = true;
            Ok(Some(true))
        }
        EditorInput::Tab | EditorInput::Enter => {
            let submit_allowed = matches!(input, EditorInput::Enter);
            match slash_palette_accept_from_palette(
                &buffer,
                &palette,
                state.slash_keyboard_mode,
                submit_allowed,
            ) {
                Some(SlashPaletteAccept::Insert(replacement)) => {
                    state.editor.replace_buffer(replacement);
                    state.reset_slash_navigation();
                    Ok(Some(true))
                }
                Some(SlashPaletteAccept::Submit(command)) => {
                    state.editor.replace_buffer(command);
                    let action = state.editor.handle(EditorInput::Enter);
                    state.reset_slash_navigation();
                    handle_tui_editor_action(session, provider, state, action).map(Some)
                }
                None => Ok(None),
            }
        }
        EditorInput::Escape => {
            state.slash_palette_suppressed = true;
            state.slash_keyboard_mode = false;
            Ok(Some(true))
        }
        EditorInput::CtrlC => {
            state.slash_palette_suppressed = true;
            state.slash_keyboard_mode = false;
            state.editor.arm_ctrl_c_exit();
            Ok(Some(true))
        }
        _ => Ok(None),
    }
}

fn handle_tui_overlay_key(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    key: event::KeyEvent,
) -> Result<bool, String> {
    let Some(input) = editor_input_from_key(key) else {
        return Ok(true);
    };
    match state.overlay.as_mut() {
        Some(TuiOverlay::Settings { selected }) => match input {
            EditorInput::Up => *selected = selected.saturating_sub(1),
            EditorInput::Down => {
                *selected =
                    (*selected + 1).min(settings_items(session, provider).len().saturating_sub(1));
            }
            EditorInput::Home | EditorInput::PageUp => *selected = 0,
            EditorInput::End | EditorInput::PageDown => {
                *selected = settings_items(session, provider).len().saturating_sub(1);
            }
            EditorInput::Enter => {
                let selected = *selected;
                activate_settings_item(session, provider, state, selected)?;
            }
            EditorInput::Text(text) if text == " " => {
                let selected = *selected;
                activate_settings_item(session, provider, state, selected)?;
            }
            EditorInput::Escape => state.overlay = None,
            EditorInput::CtrlC => {
                state.overlay = None;
                state.editor.arm_ctrl_c_exit();
            }
            EditorInput::CtrlD => return Ok(false),
            _ => {}
        },
        Some(TuiOverlay::SettingsPanel {
            panel,
            selected,
            items,
        }) => match input {
            EditorInput::Up => *selected = selected.saturating_sub(1),
            EditorInput::Down => *selected = (*selected + 1).min(items.len().saturating_sub(1)),
            EditorInput::Home | EditorInput::PageUp => *selected = 0,
            EditorInput::End | EditorInput::PageDown => *selected = items.len().saturating_sub(1),
            EditorInput::Enter => {
                let chosen = items.get(*selected).cloned();
                if let Some(chosen) = chosen {
                    activate_settings_panel_item(session, provider, state, &chosen)?;
                }
            }
            EditorInput::Text(text) if text == " " => {
                let chosen = items.get(*selected).cloned();
                if let Some(chosen) = chosen {
                    activate_settings_panel_item(session, provider, state, &chosen)?;
                }
            }
            EditorInput::Backspace | EditorInput::BackTab | EditorInput::Left => {
                if let Some(parent) = settings_parent_panel(*panel) {
                    open_settings_subpanel(session, provider, state, parent);
                } else {
                    state.overlay = Some(TuiOverlay::Settings { selected: 0 });
                }
            }
            EditorInput::Escape => state.overlay = None,
            EditorInput::CtrlC => {
                state.overlay = None;
                state.editor.arm_ctrl_c_exit();
            }
            EditorInput::CtrlD => return Ok(false),
            _ => {}
        },
        Some(TuiOverlay::Sessions {
            selected,
            query,
            items,
        }) => match input {
            EditorInput::Text(text) => {
                query.push_str(&text);
                *selected = 0;
            }
            EditorInput::Backspace | EditorInput::Delete => {
                query.pop();
                *selected = 0;
            }
            EditorInput::Up => *selected = selected.saturating_sub(1),
            EditorInput::Down => {
                *selected = (*selected + 1)
                    .min(filtered_session_items(items, query).len().saturating_sub(1));
            }
            EditorInput::PageUp => *selected = selected.saturating_sub(8),
            EditorInput::PageDown => {
                *selected = (*selected + 8)
                    .min(filtered_session_items(items, query).len().saturating_sub(1));
            }
            EditorInput::Home => *selected = 0,
            EditorInput::End => {
                *selected = filtered_session_items(items, query).len().saturating_sub(1);
            }
            EditorInput::Enter => {
                let chosen = selected_session_item(items, query, *selected).cloned();
                state.overlay = None;
                if let Some(chosen) = chosen {
                    resume_session_picker_item(session, &chosen)?;
                }
            }
            EditorInput::Escape => state.overlay = None,
            EditorInput::CtrlC => {
                state.overlay = None;
                state.editor.arm_ctrl_c_exit();
            }
            EditorInput::CtrlD => return Ok(false),
            _ => {}
        },
        Some(TuiOverlay::Models {
            selected,
            query,
            items,
        }) => match input {
            EditorInput::Text(text) => {
                query.push_str(&text);
                *selected = 0;
            }
            EditorInput::Backspace | EditorInput::Delete => {
                query.pop();
                *selected = 0;
            }
            EditorInput::Up => *selected = selected.saturating_sub(1),
            EditorInput::Down => {
                *selected =
                    (*selected + 1).min(filtered_model_items(items, query).len().saturating_sub(1));
            }
            EditorInput::PageUp => *selected = selected.saturating_sub(8),
            EditorInput::PageDown => {
                *selected =
                    (*selected + 8).min(filtered_model_items(items, query).len().saturating_sub(1));
            }
            EditorInput::Home => *selected = 0,
            EditorInput::End => {
                *selected = filtered_model_items(items, query).len().saturating_sub(1);
            }
            EditorInput::Enter => {
                let chosen = selected_model_item(items, query, *selected).cloned();
                state.overlay = None;
                if let Some(chosen) = chosen {
                    activate_model_picker_item(session, provider, &chosen)?;
                }
            }
            EditorInput::Escape => state.overlay = None,
            EditorInput::CtrlC => {
                state.overlay = None;
                state.editor.arm_ctrl_c_exit();
            }
            EditorInput::CtrlD => return Ok(false),
            _ => {}
        },
        None => state.overlay = None,
    }
    Ok(true)
}

fn handle_tui_editor_action(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    action: EditorAction,
) -> Result<bool, String> {
    match action {
        EditorAction::None => Ok(true),
        EditorAction::Cleared => {
            session.print_text("editor cleared", false)?;
            Ok(true)
        }
        EditorAction::OpenSettings => {
            state.overlay = Some(TuiOverlay::Settings { selected: 0 });
            Ok(true)
        }
        EditorAction::Exit => {
            if session.is_turn_running() {
                session.print_text(
                    "turn still running; press Escape/Ctrl+C to interrupt before Ctrl+D exit",
                    false,
                )?;
                Ok(true)
            } else {
                Ok(false)
            }
        }
        EditorAction::Submit(prompt) => {
            let prompt = prompt.trim();
            if prompt.is_empty() {
                return Ok(true);
            }
            if matches!(prompt, "/settings" | "/prefs" | "/preferences") {
                state.overlay = Some(TuiOverlay::Settings { selected: 0 });
                return Ok(true);
            }
            if matches!(prompt, "/tree" | "/sessions" | "/resume") {
                open_sessions_overlay(session, state)?;
                return Ok(true);
            }
            if matches!(prompt, "/model" | "/models" | "/roles" | "/role-model") {
                open_models_overlay(session, provider, state)?;
                return Ok(true);
            }
            match prompt {
                "/theme" | "/themes" => {
                    open_settings_subpanel(session, provider, state, SettingsSubpanel::Theme);
                    return Ok(true);
                }
                "/permissions" | "/sandbox" => {
                    open_settings_subpanel(session, provider, state, SettingsSubpanel::Permissions);
                    return Ok(true);
                }
                "/provider" => {
                    open_settings_subpanel(session, provider, state, SettingsSubpanel::Provider);
                    return Ok(true);
                }
                "/login" => {
                    open_settings_subpanel(session, provider, state, SettingsSubpanel::Login);
                    return Ok(true);
                }
                "/memory" | "/mem" => {
                    open_settings_subpanel(session, provider, state, SettingsSubpanel::Memory);
                    return Ok(true);
                }
                _ => {}
            }
            if prompt.starts_with('/') {
                return session.handle_command(prompt, provider, false);
            }
            if session.handle_login_picker_input(prompt, provider, false)? {
                return Ok(true);
            }
            if session.is_turn_running() || session.has_pending_pause() {
                session.queue_follow_up(prompt, false)?;
            } else {
                session.start_turn_for_role(prompt, provider, false, Some("executor"))?;
            }
            Ok(true)
        }
        EditorAction::SubmitFollowUp(prompt) => {
            session.queue_follow_up(prompt.trim(), false)?;
            if !session.is_turn_running() && !session.has_pending_pause() {
                session.start_next_queued_follow_up(provider, false)?;
            }
            Ok(true)
        }
        EditorAction::Steer(prompt) => {
            session.steer_active_turn(prompt.trim(), false)?;
            Ok(true)
        }
        EditorAction::RestoreQueued => {
            if let Some(restored) = session.restore_latest_follow_up() {
                state.editor.replace_buffer(restored);
                session.print_text("restored queued follow-up into editor", false)?;
            } else {
                session.print_text("no queued follow-up to restore", false)?;
            }
            Ok(true)
        }
        EditorAction::Interrupt => {
            session.interrupt_active_turn(false)?;
            Ok(true)
        }
    }
}

fn editor_input_from_key(key: event::KeyEvent) -> Option<EditorInput> {
    let modifiers = key.modifiers;
    match key.code {
        KeyCode::Char('c') if modifiers.contains(KeyModifiers::CONTROL) => Some(EditorInput::CtrlC),
        KeyCode::Char('d') if modifiers.contains(KeyModifiers::CONTROL) => Some(EditorInput::CtrlD),
        KeyCode::Char('p') if modifiers.contains(KeyModifiers::CONTROL) => Some(EditorInput::CtrlP),
        KeyCode::Char(ch) => Some(EditorInput::Text(ch.to_string())),
        KeyCode::BackTab => Some(EditorInput::BackTab),
        KeyCode::Tab => Some(EditorInput::Tab),
        KeyCode::Enter if modifiers.contains(KeyModifiers::SHIFT) => Some(EditorInput::ShiftEnter),
        KeyCode::Enter if modifiers.contains(KeyModifiers::CONTROL) => Some(EditorInput::CtrlEnter),
        KeyCode::Enter if modifiers.contains(KeyModifiers::ALT) => Some(EditorInput::AltEnter),
        KeyCode::Enter => Some(EditorInput::Enter),
        KeyCode::Esc => Some(EditorInput::Escape),
        KeyCode::Backspace => Some(EditorInput::Backspace),
        KeyCode::Delete => Some(EditorInput::Delete),
        KeyCode::Left => Some(EditorInput::Left),
        KeyCode::Right => Some(EditorInput::Right),
        KeyCode::Home => Some(EditorInput::Home),
        KeyCode::End => Some(EditorInput::End),
        KeyCode::PageUp => Some(EditorInput::PageUp),
        KeyCode::PageDown => Some(EditorInput::PageDown),
        KeyCode::Up if modifiers.contains(KeyModifiers::ALT) => Some(EditorInput::AltUp),
        KeyCode::Up => Some(EditorInput::Up),
        KeyCode::Down => Some(EditorInput::Down),
        _ => None,
    }
}

fn activate_settings_item(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    selected: usize,
) -> Result<(), String> {
    match selected {
        0 => open_settings_subpanel(session, provider, state, SettingsSubpanel::Theme),
        1 => open_settings_subpanel(session, provider, state, SettingsSubpanel::Permissions),
        2 => {
            open_models_overlay(session, provider, state)?;
        }
        3 => open_settings_subpanel(session, provider, state, SettingsSubpanel::Provider),
        4 => open_settings_subpanel(session, provider, state, SettingsSubpanel::Login),
        5 => {
            open_sessions_overlay(session, state)?;
        }
        6 => open_settings_subpanel(session, provider, state, SettingsSubpanel::Memory),
        _ => {}
    }
    session.sync_ui_docks();
    Ok(())
}

fn open_settings_subpanel(
    session: &ShellSession,
    provider: &ProviderConfig,
    state: &mut NativeTuiState,
    panel: SettingsSubpanel,
) {
    let items = settings_panel_items(session, provider, panel);
    let selected = items
        .iter()
        .position(|item| item.current)
        .unwrap_or_default();
    state.overlay = Some(TuiOverlay::SettingsPanel {
        panel,
        selected,
        items,
    });
}

fn settings_panel_items(
    session: &ShellSession,
    provider: &ProviderConfig,
    panel: SettingsSubpanel,
) -> Vec<SettingsPanelItem> {
    match panel {
        SettingsSubpanel::Theme => theme_settings_panel_items(session),
        SettingsSubpanel::Permissions => permission_settings_panel_items(session),
        SettingsSubpanel::Provider => provider_settings_panel_items(provider),
        SettingsSubpanel::Login => login_settings_panel_items(provider),
        SettingsSubpanel::LoginSubscription => login_subscription_settings_panel_items(),
        SettingsSubpanel::LoginApi => login_api_settings_panel_items(provider),
        SettingsSubpanel::LoginClaude => login_claude_settings_panel_items(),
        SettingsSubpanel::Memory => memory_settings_panel_items(),
    }
}

fn theme_settings_panel_items(session: &ShellSession) -> Vec<SettingsPanelItem> {
    [
        ("OPPi", "oppi", "Default OPPi accent theme"),
        ("Dark", "dark", "Low-contrast dark terminal theme"),
        ("Light", "light", "Light terminal theme"),
        ("Plain", "plain", "No-color terminal-safe theme"),
        ("Reload file", "reload", "Reload .oppi/theme.txt if present"),
    ]
    .into_iter()
    .map(|(label, theme, detail)| {
        settings_command_item(
            label,
            theme,
            detail,
            session.theme == theme,
            format!("/theme {theme}"),
        )
    })
    .collect()
}

fn permission_settings_panel_items(session: &ShellSession) -> Vec<SettingsPanelItem> {
    [
        (
            "Read only",
            "read-only",
            "Allow reads and block write/network actions",
        ),
        ("Default", "default", "Balanced local development policy"),
        (
            "Auto review",
            "auto-review",
            "Review risky actions before execution",
        ),
        (
            "Full access",
            "full-access",
            "Allow unrestricted local tool actions",
        ),
    ]
    .into_iter()
    .map(|(label, mode, detail)| {
        settings_command_item(
            label,
            mode,
            detail,
            session.permission_mode.as_str() == mode,
            format!("/permissions {mode}"),
        )
    })
    .collect()
}

fn provider_settings_panel_items(provider: &ProviderConfig) -> Vec<SettingsPanelItem> {
    let openai_env = match provider {
        ProviderConfig::OpenAiCompatible(config) => config.api_key_env.as_deref(),
        ProviderConfig::Mock => None,
    };
    let mut items = vec![
        settings_command_item(
            "Status",
            provider.label(),
            "Show redacted provider/model/auth status",
            true,
            "/provider status",
        ),
        settings_command_item(
            "Validate",
            "local",
            "Run redacted local readiness checks (no model call)",
            false,
            "/provider validate",
        ),
        settings_command_item(
            "Policy",
            "safety",
            "Explain provider auth/network policy",
            false,
            "/provider policy",
        ),
        settings_command_item(
            "Anthropic bridge",
            "Meridian",
            "Show explicit Claude/Meridian compatibility notes",
            false,
            "/provider anthropic",
        ),
    ];
    for env_name in ["OPPI_OPENAI_API_KEY", "OPENAI_API_KEY"] {
        items.push(settings_command_item(
            "Use OpenAI env",
            env_name,
            "Configure by env-reference only; raw keys are rejected",
            openai_env == Some(env_name),
            format!("/login api openai env {env_name}"),
        ));
    }
    items.push(settings_edit_item(
        "Custom API env",
        "edit",
        "Insert /login api openai env <ENV> into the editor",
        "/login api openai env ",
    ));
    items.push(settings_edit_item(
        "Base URL",
        "edit",
        "Insert /provider base-url <url> into the editor",
        "/provider base-url ",
    ));
    items.push(settings_edit_item(
        "Smoke",
        "live",
        "Insert live provider smoke command for explicit review",
        "/provider smoke ",
    ));
    items.push(settings_command_item(
        "Logout provider",
        "session",
        "Clear direct-provider settings for this shell session",
        false,
        "/logout provider",
    ));
    items
}

fn login_settings_panel_items(provider: &ProviderConfig) -> Vec<SettingsPanelItem> {
    vec![
        settings_panel_link_item(
            "Subscription auth",
            "providers",
            "Codex, Claude/Meridian, or Copilot guidance",
            SettingsSubpanel::LoginSubscription,
            true,
        ),
        settings_panel_link_item(
            "API auth",
            "env-ref",
            "OpenAI-compatible setup with environment references only",
            SettingsSubpanel::LoginApi,
            false,
        ),
        settings_command_item(
            "Status",
            provider.label(),
            "Show the current login/provider status",
            false,
            "/provider status",
        ),
        settings_command_item(
            "Logout provider",
            "session",
            "Clear native direct-provider settings for this session",
            false,
            "/logout provider",
        ),
    ]
}

fn login_subscription_settings_panel_items() -> Vec<SettingsPanelItem> {
    vec![
        settings_command_item(
            "Codex (ChatGPT)",
            "native OAuth",
            "Open browser sign-in and save redacted auth-store token",
            false,
            "/login subscription codex",
        ),
        settings_panel_link_item(
            "Claude (Anthropic)",
            "Meridian",
            "Explicit managed loopback bridge; no hidden install/start",
            SettingsSubpanel::LoginClaude,
            true,
        ),
        settings_command_item(
            "Copilot (Microsoft)",
            "stable OPPi",
            "Delegates to stable Pi/OPPi login today",
            false,
            "/login subscription copilot",
        ),
    ]
}

fn login_api_settings_panel_items(provider: &ProviderConfig) -> Vec<SettingsPanelItem> {
    let openai_env = match provider {
        ProviderConfig::OpenAiCompatible(config) => config.api_key_env.as_deref(),
        ProviderConfig::Mock => None,
    };
    vec![
        settings_command_item(
            "OpenAI guidance",
            "env-ref",
            "Show safe API-key environment-variable setup",
            false,
            "/login api openai",
        ),
        settings_command_item(
            "Use OPPI_OPENAI_API_KEY",
            "env-ref",
            "Configure without storing a raw secret",
            openai_env == Some("OPPI_OPENAI_API_KEY"),
            "/login api openai env OPPI_OPENAI_API_KEY",
        ),
        settings_command_item(
            "Use OPENAI_API_KEY",
            "env-ref",
            "Configure without storing a raw secret",
            openai_env == Some("OPENAI_API_KEY"),
            "/login api openai env OPENAI_API_KEY",
        ),
        settings_edit_item(
            "Custom API env",
            "edit",
            "Insert /login api openai env <ENV> into the editor",
            "/login api openai env ",
        ),
    ]
}

fn login_claude_settings_panel_items() -> Vec<SettingsPanelItem> {
    vec![
        settings_command_item(
            "Status",
            "Meridian",
            "Check explicit managed bridge status",
            true,
            "/login subscription claude status",
        ),
        settings_command_item(
            "Use bridge",
            "loopback",
            "Configure explicit bridge if already running",
            false,
            "/login subscription claude use",
        ),
        settings_command_item(
            "Start bridge",
            "start",
            "Try visible user-selected Meridian startup candidates",
            false,
            "/login subscription claude start",
        ),
        settings_command_item(
            "Install bridge",
            "approval",
            "Ask before installing managed Meridian dependency",
            false,
            "/login subscription claude install",
        ),
        settings_command_item(
            "Stop bridge",
            "stop",
            "Stop only the bridge started by this shell session",
            false,
            "/login subscription claude stop",
        ),
    ]
}

fn memory_settings_panel_items() -> Vec<SettingsPanelItem> {
    vec![
        settings_command_item(
            "Status",
            "client-hosted",
            "Show Hoppi/native memory status",
            false,
            "/memory status",
        ),
        settings_command_item(
            "Enable",
            "on",
            "Enable client-hosted project memory",
            false,
            "/memory on",
        ),
        settings_command_item(
            "Disable",
            "off",
            "Disable memory for this session/project scope",
            false,
            "/memory off",
        ),
        settings_command_item(
            "Dashboard",
            "view",
            "Open client-hosted memory dashboard panel",
            false,
            "/memory dashboard",
        ),
        settings_command_item(
            "Settings",
            "view",
            "Open client-hosted memory settings panel",
            false,
            "/memory settings",
        ),
        settings_command_item(
            "Maintenance preview",
            "dry-run",
            "Preview memory maintenance without applying changes",
            false,
            "/memory maintenance dry-run",
        ),
        settings_command_item(
            "Maintenance apply",
            "explicit",
            "Apply memory maintenance only after this explicit selection",
            false,
            "/memory maintenance apply",
        ),
        settings_edit_item(
            "Record compaction",
            "edit",
            "Insert /memory compact <summary> into the editor",
            "/memory compact ",
        ),
    ]
}

fn settings_command_item(
    label: impl Into<String>,
    value: impl Into<String>,
    detail: impl Into<String>,
    current: bool,
    command: impl Into<String>,
) -> SettingsPanelItem {
    SettingsPanelItem {
        label: label.into(),
        value: value.into(),
        detail: detail.into(),
        current,
        action: SettingsPanelAction::Command(command.into()),
    }
}

fn settings_edit_item(
    label: impl Into<String>,
    value: impl Into<String>,
    detail: impl Into<String>,
    command: impl Into<String>,
) -> SettingsPanelItem {
    SettingsPanelItem {
        label: label.into(),
        value: value.into(),
        detail: detail.into(),
        current: false,
        action: SettingsPanelAction::EditCommand(command.into()),
    }
}

fn settings_panel_link_item(
    label: impl Into<String>,
    value: impl Into<String>,
    detail: impl Into<String>,
    panel: SettingsSubpanel,
    current: bool,
) -> SettingsPanelItem {
    SettingsPanelItem {
        label: label.into(),
        value: value.into(),
        detail: detail.into(),
        current,
        action: SettingsPanelAction::OpenPanel(panel),
    }
}

fn activate_settings_panel_item(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    state: &mut NativeTuiState,
    item: &SettingsPanelItem,
) -> Result<(), String> {
    match &item.action {
        SettingsPanelAction::Command(command) => {
            state.overlay = None;
            let _ = session.handle_command(command, provider, false)?;
        }
        SettingsPanelAction::EditCommand(command) => {
            state.overlay = None;
            state.editor.replace_buffer(command.clone());
        }
        SettingsPanelAction::OpenPanel(panel) => {
            open_settings_subpanel(session, provider, state, *panel);
        }
    }
    session.sync_ui_docks();
    Ok(())
}

fn settings_parent_panel(panel: SettingsSubpanel) -> Option<SettingsSubpanel> {
    match panel {
        SettingsSubpanel::LoginSubscription
        | SettingsSubpanel::LoginApi
        | SettingsSubpanel::LoginClaude => Some(SettingsSubpanel::Login),
        _ => None,
    }
}

fn settings_subpanel_title(panel: SettingsSubpanel) -> &'static str {
    match panel {
        SettingsSubpanel::Theme => "theme",
        SettingsSubpanel::Permissions => "permissions",
        SettingsSubpanel::Provider => "provider",
        SettingsSubpanel::Login => "login",
        SettingsSubpanel::LoginSubscription => "login › subscription",
        SettingsSubpanel::LoginApi => "login › api",
        SettingsSubpanel::LoginClaude => "login › claude",
        SettingsSubpanel::Memory => "memory",
    }
}

fn open_sessions_overlay(
    session: &mut ShellSession,
    state: &mut NativeTuiState,
) -> Result<(), String> {
    let items = session_picker_items(session)?;
    let selected = items
        .iter()
        .position(|item| item.current)
        .unwrap_or_default();
    state.overlay = Some(TuiOverlay::Sessions {
        selected,
        query: String::new(),
        items,
    });
    Ok(())
}

fn session_picker_items(session: &mut ShellSession) -> Result<Vec<SessionPickerItem>, String> {
    let value = session.rpc.request("thread/list", json!({}))?;
    let result: RuntimeListResult<Thread> = serde_json::from_value(value)
        .map_err(|error| format!("decode thread/list for session picker: {error}"))?;
    Ok(result
        .items
        .into_iter()
        .map(|thread| {
            let cwd = thread.project.cwd;
            SessionPickerItem {
                current: thread.id == session.thread_id,
                id: thread.id,
                title: thread
                    .title
                    .unwrap_or_else(|| "Untitled session".to_string()),
                status: format!("{:?}", thread.status),
                cwd,
                forked_from: thread.forked_from,
            }
        })
        .collect())
}

fn filtered_session_items<'a>(
    items: &'a [SessionPickerItem],
    query: &str,
) -> Vec<(usize, &'a SessionPickerItem)> {
    let query = query.trim().to_ascii_lowercase();
    items
        .iter()
        .enumerate()
        .filter(|(_, item)| {
            query.is_empty()
                || item.id.to_ascii_lowercase().contains(&query)
                || item.title.to_ascii_lowercase().contains(&query)
                || item.cwd.to_ascii_lowercase().contains(&query)
                || item.status.to_ascii_lowercase().contains(&query)
                || item
                    .forked_from
                    .as_deref()
                    .unwrap_or_default()
                    .to_ascii_lowercase()
                    .contains(&query)
        })
        .collect()
}

fn selected_session_item<'a>(
    items: &'a [SessionPickerItem],
    query: &str,
    selected: usize,
) -> Option<&'a SessionPickerItem> {
    filtered_session_items(items, query)
        .get(selected)
        .map(|(_, item)| *item)
}

fn resume_session_picker_item(
    session: &mut ShellSession,
    item: &SessionPickerItem,
) -> Result<(), String> {
    if item.current || item.id == session.thread_id {
        return session.print_text(&format!("already on session {}", item.id), false);
    }
    let value = session
        .rpc
        .request("thread/resume", json!({ "threadId": item.id }))?;
    session.switch_to_thread(value, false, "resumed")
}

fn open_models_overlay(
    session: &mut ShellSession,
    provider: &ProviderConfig,
    state: &mut NativeTuiState,
) -> Result<(), String> {
    let items = model_picker_items(session, provider)?;
    state.overlay = Some(TuiOverlay::Models {
        selected: 0,
        query: String::new(),
        items,
    });
    Ok(())
}

fn model_picker_items(
    session: &mut ShellSession,
    provider: &ProviderConfig,
) -> Result<Vec<ModelPickerItem>, String> {
    let _ = session.list_models()?;
    let mut model_ids = session.known_model_ids.clone();
    if let Some(model) = session.session_model(provider) {
        model_ids.insert(model.to_string());
    }
    for model in session.role_models.values() {
        model_ids.insert(model.clone());
    }
    if model_ids.is_empty() {
        model_ids.insert("mock-scripted".to_string());
    }

    let session_model = session.session_model(provider).map(str::to_string);
    let mut items = Vec::new();
    for model in &model_ids {
        items.push(ModelPickerItem {
            label: format!("session model: {model}"),
            detail: "Set the model for normal executor turns".to_string(),
            current: session_model.as_deref() == Some(model.as_str()),
            action: ModelPickerAction::SelectSession(model.clone()),
        });
    }
    for role in ROLE_NAMES {
        let inherited = session
            .session_model(provider)
            .unwrap_or("session model")
            .to_string();
        items.push(ModelPickerItem {
            label: format!("role {role}: inherit"),
            detail: format!("Clear override; use {inherited}"),
            current: !session.role_models.contains_key(role),
            action: ModelPickerAction::ClearRole {
                role: role.to_string(),
            },
        });
        for model in &model_ids {
            items.push(ModelPickerItem {
                label: format!("role {role}: {model}"),
                detail: format!("Use {model} for {role} turns"),
                current: session
                    .role_models
                    .get(role)
                    .is_some_and(|current| current == model),
                action: ModelPickerAction::SelectRole {
                    role: role.to_string(),
                    model: model.clone(),
                },
            });
        }
    }
    Ok(items)
}

fn filtered_model_items<'a>(
    items: &'a [ModelPickerItem],
    query: &str,
) -> Vec<(usize, &'a ModelPickerItem)> {
    let query = query.trim().to_ascii_lowercase();
    items
        .iter()
        .enumerate()
        .filter(|(_, item)| {
            query.is_empty()
                || item.label.to_ascii_lowercase().contains(&query)
                || item.detail.to_ascii_lowercase().contains(&query)
                || model_picker_action_text(&item.action)
                    .to_ascii_lowercase()
                    .contains(&query)
        })
        .collect()
}

fn selected_model_item<'a>(
    items: &'a [ModelPickerItem],
    query: &str,
    selected: usize,
) -> Option<&'a ModelPickerItem> {
    filtered_model_items(items, query)
        .get(selected)
        .map(|(_, item)| *item)
}

fn cycle_session_model(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    reverse: bool,
) -> Result<(), String> {
    let _ = session.list_models()?;
    let mut models = session.known_model_ids.iter().cloned().collect::<Vec<_>>();
    if let Some(current) = session.session_model(provider)
        && !models.iter().any(|model| model == current)
    {
        models.push(current.to_string());
    }
    models.sort();
    models.dedup();
    if models.is_empty() {
        return session.print_text("no models available; use /login or /model", false);
    }
    let current = session.session_model(provider).unwrap_or_default();
    let current_index = models
        .iter()
        .position(|model| model == current)
        .unwrap_or(0);
    let next_index = if reverse {
        (current_index + models.len() - 1) % models.len()
    } else {
        (current_index + 1) % models.len()
    };
    session.select_session_model(provider, &models[next_index], false)
}

fn cycle_reasoning_effort(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
) -> Result<(), String> {
    let levels = ["off", "low", "medium", "high"];
    let current = match provider {
        ProviderConfig::Mock => {
            return session.print_text(
                "thinking level: mock provider has no reasoning-effort setting",
                false,
            );
        }
        ProviderConfig::OpenAiCompatible(config) => config
            .reasoning_effort
            .as_deref()
            .unwrap_or("off")
            .to_string(),
    };
    let current_index = levels
        .iter()
        .position(|level| level.eq_ignore_ascii_case(&current))
        .unwrap_or(0);
    let next = levels[(current_index + 1) % levels.len()];
    session.handle_command(&format!("/effort {next}"), provider, false)?;
    Ok(())
}

fn model_picker_action_text(action: &ModelPickerAction) -> String {
    match action {
        ModelPickerAction::SelectSession(model) => format!("session {model}"),
        ModelPickerAction::SelectRole { role, model } => format!("role {role} {model}"),
        ModelPickerAction::ClearRole { role } => format!("role {role} inherit"),
    }
}

fn activate_model_picker_item(
    session: &mut ShellSession,
    provider: &mut ProviderConfig,
    item: &ModelPickerItem,
) -> Result<(), String> {
    match &item.action {
        ModelPickerAction::SelectSession(model) => {
            session.select_session_model(provider, model, false)?;
        }
        ModelPickerAction::SelectRole { role, model } => {
            session.role_models.insert(role.clone(), model.clone());
            save_role_profiles(&session.role_profile_path, &session.role_models)?;
            session.register_model_ref(model, provider_name(provider), Some(role))?;
            session.print_text(
                &format!("role {role} model set to {model} (persisted)"),
                false,
            )?;
        }
        ModelPickerAction::ClearRole { role } => {
            session.role_models.remove(role);
            save_role_profiles(&session.role_profile_path, &session.role_models)?;
            session.print_text(
                &format!(
                    "role {role} now inherits {} (persisted)",
                    session.session_model(provider).unwrap_or("session model")
                ),
                false,
            )?;
        }
    }
    session.sync_ui_docks();
    Ok(())
}

fn settings_items<'a>(
    session: &'a ShellSession,
    provider: &'a ProviderConfig,
) -> Vec<(&'static str, String, &'static str)> {
    vec![
        ("Theme", session.theme.clone(), "Enter opens theme panel"),
        (
            "Permissions",
            session.permission_mode.as_str().to_string(),
            "Enter opens permissions panel",
        ),
        (
            "Model",
            session
                .session_model(provider)
                .unwrap_or("none")
                .to_string(),
            "Enter opens model selector",
        ),
        (
            "Provider",
            provider.label().to_string(),
            "Enter opens provider panel",
        ),
        (
            "Login",
            "auth/provider setup".to_string(),
            "Enter opens login panel",
        ),
        (
            "Sessions",
            session.thread_id.clone(),
            "Enter opens session picker",
        ),
        (
            "Memory",
            "client-hosted Hoppi".to_string(),
            "Enter opens memory panel",
        ),
    ]
}

fn render_native_tui_frame(
    session: &ShellSession,
    provider: &ProviderConfig,
    state: &NativeTuiState,
    width: usize,
    height: usize,
) -> Vec<String> {
    let width = width.max(50);
    let height = height.max(14);
    let tokens = theme_tokens(&session.theme);

    let header = render_tui_header(session, provider, state, width, tokens);
    let dock_lines = render_tui_docks(session, width, tokens);
    let overlay_lines = state
        .overlay
        .as_ref()
        .map(|overlay| render_overlay_lines(overlay, session, provider, width, height, tokens))
        .unwrap_or_default();
    let editor_lines = render_tui_editor(&state.editor, width, session.is_turn_running(), tokens);
    let slash_palette_lines = state
        .current_slash_palette(session)
        .map(|palette| render_slash_palette(&palette, width, 5, tokens))
        .unwrap_or_default();
    let footer_lines = render_tui_footer(session, provider, width, tokens);

    let reserved = 1
        + dock_lines.len()
        + overlay_lines.len()
        + editor_lines.len()
        + slash_palette_lines.len()
        + footer_lines.len();
    let transcript_height = height.saturating_sub(reserved).max(3);

    let mut lines = Vec::new();
    lines.push(header);
    lines.extend(render_tui_transcript(
        session,
        width,
        transcript_height,
        tokens,
    ));
    lines.extend(dock_lines);
    lines.extend(overlay_lines);
    lines.extend(editor_lines);
    lines.extend(slash_palette_lines);
    lines.extend(footer_lines);

    while lines.len() < height {
        lines.push(tui_pad_line("", width));
    }
    lines.truncate(height);
    lines
        .into_iter()
        .map(|line| tui_pad_line(&line, width))
        .collect()
}

fn render_tui_header(
    session: &ShellSession,
    provider: &ProviderConfig,
    state: &NativeTuiState,
    width: usize,
    tokens: ThemeTokens,
) -> String {
    let spinner = if session.is_turn_running() {
        SPINNER_FRAMES[state.spinner_index % SPINNER_FRAMES.len()]
    } else if session.has_pending_pause() {
        "⏸"
    } else {
        "●"
    };
    let title = format!(
        " {spinner} OPPi native  model={}  provider={}  permissions={}  thread={} ",
        session.session_model(provider).unwrap_or("none"),
        provider.label(),
        session.permission_mode.as_str(),
        session.thread_id
    );
    let painted = paint(tokens, tokens.accent, title);
    tui_box_line('╭', '─', '╮', Some(&painted), width)
}

fn render_tui_transcript(
    session: &ShellSession,
    width: usize,
    max_lines: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let inner = width.saturating_sub(4).max(10);
    let mut collected = Vec::new();
    for entry in session.ui.scrollback.iter().rev() {
        for line in entry.lines().rev() {
            collected.push(format!(
                "│ {} │",
                tui_pad_line(&tui_truncate(line, inner), inner)
            ));
            if collected.len() >= max_lines {
                break;
            }
        }
        if collected.len() >= max_lines {
            break;
        }
    }
    if collected.is_empty() {
        collected.push(format!(
            "│ {} │",
            tui_pad_line(
                &paint(
                    tokens,
                    tokens.dim,
                    "No transcript yet — type a prompt or /settings."
                ),
                inner
            )
        ));
    }
    collected.reverse();
    while collected.len() < max_lines {
        collected.insert(0, format!("│ {} │", tui_pad_line("", inner)));
    }
    collected
}

fn render_tui_docks(session: &ShellSession, width: usize, tokens: ThemeTokens) -> Vec<String> {
    let inner = width.saturating_sub(4).max(10);
    let dock_lines = session.ui.dock_lines(inner);
    if dock_lines.is_empty() {
        return vec![format!(
            "├{}┤",
            tui_pad_line(
                &paint(tokens, tokens.dim, " docks: idle "),
                width.saturating_sub(2)
            )
        )];
    }
    let mut lines = vec![format!(
        "├{}┤",
        tui_pad_line(
            &paint(tokens, tokens.dim, " docks "),
            width.saturating_sub(2)
        )
    )];
    for line in dock_lines.into_iter().take(5) {
        lines.push(format!(
            "│ {} │",
            tui_pad_line(&tui_truncate(&line, inner), inner)
        ));
    }
    lines
}

fn render_slash_palette(
    palette: &SlashPalette,
    width: usize,
    max_entries: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let count = palette.items.len();
    if count == 0 {
        return Vec::new();
    }
    let max_entries = max_entries.max(1).min(5).min(count);
    let selected = palette.selected.min(count.saturating_sub(1));
    let start = selected.saturating_add(1).saturating_sub(max_entries);
    let end = (start + max_entries).min(count);
    let mut lines = Vec::new();
    for (index, item) in palette
        .items
        .iter()
        .enumerate()
        .skip(start)
        .take(end.saturating_sub(start))
    {
        let marker = if index == selected { "→" } else { " " };
        let label = if index == selected {
            paint(tokens, tokens.accent, &item.label)
        } else {
            item.label.clone()
        };
        let detail = paint(tokens, tokens.dim, &item.detail);
        let row = if width >= 72 {
            let label_width = 34usize.min(width.saturating_sub(20));
            let label_cell = tui_pad_line(&tui_truncate(&label, label_width), label_width);
            format!("{marker} {label_cell} {detail}")
        } else {
            format!("{marker} {label} {detail}")
        };
        lines.push(tui_pad_line(&tui_truncate(&row, width), width));
    }
    if count > max_entries {
        lines.push(tui_pad_line(
            &paint(
                tokens,
                tokens.dim,
                &format!(
                    "  {}-{} of {} • ↑↓ navigate • Enter select",
                    start + 1,
                    end,
                    count
                ),
            ),
            width,
        ));
    }
    lines
}

fn render_tui_editor(
    editor: &LineEditor,
    width: usize,
    busy: bool,
    tokens: ThemeTokens,
) -> Vec<String> {
    let mut lines = vec![tui_rule(width, tokens)];
    let rendered_buffer = render_editor_buffer(editor, width, tokens);
    for line in rendered_buffer.into_iter().take(5) {
        lines.push(tui_pad_line(&line, width));
    }
    if busy {
        lines.push(tui_pad_line(
            &paint(
                tokens,
                tokens.dim,
                "Enter queues follow-up while the turn runs",
            ),
            width,
        ));
    }
    lines.push(tui_rule(width, tokens));
    lines
}

fn render_editor_buffer(editor: &LineEditor, width: usize, _tokens: ThemeTokens) -> Vec<String> {
    let buffer = editor.buffer_preview();
    if buffer.is_empty() {
        return vec!["\x1b[7m \x1b[27m".to_string()];
    }
    let cursor = editor.cursor();
    let mut output = Vec::new();
    let mut offset = 0;
    for raw_line in buffer.split('\n') {
        let line_end = offset + raw_line.len();
        let mut line = String::new();
        if cursor >= offset && cursor <= line_end {
            let local = cursor - offset;
            let before = &raw_line[..local];
            let after = &raw_line[local..];
            let (cursor_char, rest) = split_first_char(after);
            line.push_str(before);
            line.push_str("\x1b[7m");
            line.push_str(cursor_char.unwrap_or(" "));
            line.push_str("\x1b[27m");
            line.push_str(rest);
        } else {
            line.push_str(raw_line);
        }
        output.push(tui_truncate(&line, width));
        offset = line_end + 1;
    }
    output
}

fn render_tui_footer(
    session: &ShellSession,
    provider: &ProviderConfig,
    width: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let queued = session.follow_up_queue.len();
    let todos = active_todos(&session.todo_state).len();
    let status = if session.is_turn_running() {
        "running"
    } else if session.has_pending_pause() {
        "waiting"
    } else {
        "ready"
    };
    let left = format!(
        " {} · {} · {} · {} · {}t · {}q ",
        status,
        provider.label(),
        session.session_model(provider).unwrap_or("none"),
        session.permission_mode.as_str(),
        todos,
        queued
    );
    let right = " Alt+Enter Follow-up  Alt+Up Queue  Ctrl+C×2 Exit ";
    let gap = width.saturating_sub(tui_visible_width(&left) + tui_visible_width(right));
    let key_hints =
        " Ctrl+L Model  Ctrl+P Next model  Ctrl+Shift+P Prev model  Shift+Tab Thinking ";
    vec![
        tui_pad_line(
            &format!(
                "{}{}{}",
                paint(tokens, tokens.dim, &left),
                " ".repeat(gap),
                paint(tokens, tokens.dim, right)
            ),
            width,
        ),
        tui_pad_line(&paint(tokens, tokens.dim, key_hints), width),
    ]
}

fn render_overlay_lines(
    overlay: &TuiOverlay,
    session: &ShellSession,
    provider: &ProviderConfig,
    width: usize,
    height: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    match overlay {
        TuiOverlay::Settings { selected } => {
            render_settings_overlay(session, provider, *selected, width, tokens)
        }
        TuiOverlay::SettingsPanel {
            panel,
            selected,
            items,
        } => render_settings_subpanel_overlay(*panel, items, *selected, width, height, tokens),
        TuiOverlay::Sessions {
            selected,
            query,
            items,
        } => render_sessions_overlay(items, query, *selected, width, height, tokens),
        TuiOverlay::Models {
            selected,
            query,
            items,
        } => render_models_overlay(items, query, *selected, width, height, tokens),
    }
}

fn tui_rule(width: usize, tokens: ThemeTokens) -> String {
    paint(tokens, tokens.dim, &"─".repeat(width))
}

fn render_sessions_overlay(
    items: &[SessionPickerItem],
    query: &str,
    selected: usize,
    width: usize,
    height: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let filtered = filtered_session_items(items, query);
    let count = filtered.len();
    let selected = selected.min(count.saturating_sub(1));
    let max_rows = height.saturating_sub(10).clamp(3, 10).min(count.max(1));
    let start = selected.saturating_add(1).saturating_sub(max_rows);
    let end = (start + max_rows).min(count);
    let mut lines = vec![tui_rule(width, tokens)];
    lines.push(tui_pad_line(
        &paint(tokens, tokens.accent, "Sessions"),
        width,
    ));
    let search = if query.trim().is_empty() {
        "Search sessions by title, id, path, or status".to_string()
    } else {
        format!("Search: {query}")
    };
    lines.push(tui_pad_line(&paint(tokens, tokens.dim, &search), width));
    if filtered.is_empty() {
        lines.push(tui_pad_line(
            &paint(tokens, tokens.warning, "No matching sessions"),
            width,
        ));
    } else {
        for (row, (_, item)) in filtered
            .iter()
            .enumerate()
            .skip(start)
            .take(end.saturating_sub(start))
        {
            let marker = if row == selected { "→" } else { " " };
            let current = if item.current { "●" } else { " " };
            let title = if row == selected {
                paint(tokens, tokens.accent, &item.title)
            } else {
                item.title.clone()
            };
            let fork = item
                .forked_from
                .as_deref()
                .map(|fork| format!(" forked={fork}"))
                .unwrap_or_default();
            let row_text = format!(
                "{marker} {current} {title}  {}  {}{}",
                item.status, item.cwd, fork
            );
            lines.push(tui_pad_line(&tui_truncate(&row_text, width), width));
        }
    }
    lines.push(tui_pad_line(
        &paint(
            tokens,
            tokens.dim,
            &format!(
                "{}-{} of {} · Enter to select · Esc to go back",
                start + 1,
                end,
                count
            ),
        ),
        width,
    ));
    lines.push(tui_rule(width, tokens));
    lines
}

fn render_models_overlay(
    items: &[ModelPickerItem],
    query: &str,
    selected: usize,
    width: usize,
    height: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let filtered = filtered_model_items(items, query);
    let count = filtered.len();
    let selected = selected.min(count.saturating_sub(1));
    let max_rows = height.saturating_sub(10).clamp(4, 10).min(count.max(1));
    let start = selected.saturating_add(1).saturating_sub(max_rows);
    let end = (start + max_rows).min(count);
    let mut lines = vec![tui_rule(width, tokens)];
    lines.push(tui_pad_line(
        &paint(tokens, tokens.accent, "Model selector"),
        width,
    ));
    let search = if query.trim().is_empty() {
        "Search models or roles".to_string()
    } else {
        format!("Search: {query}")
    };
    lines.push(tui_pad_line(&paint(tokens, tokens.dim, &search), width));
    if filtered.is_empty() {
        lines.push(tui_pad_line(
            &paint(tokens, tokens.warning, "No matching models/roles"),
            width,
        ));
    } else {
        for (row, (_, item)) in filtered
            .iter()
            .enumerate()
            .skip(start)
            .take(end.saturating_sub(start))
        {
            let marker = if row == selected { "→" } else { " " };
            let current = if item.current { "●" } else { " " };
            let label = if row == selected {
                paint(tokens, tokens.accent, &item.label)
            } else {
                item.label.clone()
            };
            let row_text = format!("{marker} {current} {label}  {}", item.detail);
            lines.push(tui_pad_line(&tui_truncate(&row_text, width), width));
        }
    }
    lines.push(tui_pad_line(
        &paint(
            tokens,
            tokens.dim,
            &format!(
                "{}-{} of {} · Enter to select · Esc to go back",
                start + 1,
                end,
                count
            ),
        ),
        width,
    ));
    lines.push(tui_rule(width, tokens));
    lines
}

fn render_settings_subpanel_overlay(
    panel: SettingsSubpanel,
    items: &[SettingsPanelItem],
    selected: usize,
    width: usize,
    height: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let count = items.len();
    let selected = selected.min(count.saturating_sub(1));
    let max_rows = height.saturating_sub(9).clamp(4, 10).min(count.max(1));
    let start = selected.saturating_add(1).saturating_sub(max_rows);
    let end = (start + max_rows).min(count);
    let mut lines = vec![tui_rule(width, tokens)];
    lines.push(tui_pad_line(
        &paint(
            tokens,
            tokens.accent,
            &format!("Settings › {}", settings_subpanel_title(panel)),
        ),
        width,
    ));
    if items.is_empty() {
        lines.push(tui_pad_line(
            &paint(tokens, tokens.warning, "No settings available"),
            width,
        ));
    } else {
        for (row, item) in items
            .iter()
            .enumerate()
            .skip(start)
            .take(end.saturating_sub(start))
        {
            let marker = if row == selected { "→" } else { " " };
            let current = if item.current { "●" } else { " " };
            let label = if row == selected {
                paint(tokens, tokens.accent, &item.label)
            } else {
                item.label.clone()
            };
            let row_text = format!("{marker} {current} {label:<24} {}", item.value);
            lines.push(tui_pad_line(&tui_truncate(&row_text, width), width));
        }
        if let Some(item) = items.get(selected) {
            lines.push(tui_pad_line(
                &paint(tokens, tokens.dim, &item.detail),
                width,
            ));
        }
    }
    lines.push(tui_pad_line(
        &paint(
            tokens,
            tokens.dim,
            &format!(
                "{}-{} of {} · Enter/Space to change · Esc to cancel",
                start + 1,
                end,
                count
            ),
        ),
        width,
    ));
    lines.push(tui_rule(width, tokens));
    lines
}

fn render_settings_overlay(
    session: &ShellSession,
    provider: &ProviderConfig,
    selected: usize,
    width: usize,
    tokens: ThemeTokens,
) -> Vec<String> {
    let items = settings_items(session, provider);
    let selected = selected.min(items.len().saturating_sub(1));
    let mut lines = vec![tui_rule(width, tokens)];
    lines.push(tui_pad_line(
        &paint(tokens, tokens.accent, "Settings"),
        width,
    ));
    for (index, (label, value, _hint)) in items.iter().enumerate() {
        let marker = if index == selected { "→" } else { " " };
        let label = if index == selected {
            paint(tokens, tokens.accent, label)
        } else {
            label.to_string()
        };
        let row = format!("{marker} {label:<18} {value}");
        lines.push(tui_pad_line(&tui_truncate(&row, width), width));
    }
    if let Some((_, _, hint)) = items.get(selected) {
        lines.push(tui_pad_line(&paint(tokens, tokens.dim, hint), width));
    }
    lines.push(tui_pad_line(
        &paint(tokens, tokens.dim, "Enter/Space to change · Esc to cancel"),
        width,
    ));
    lines.push(tui_rule(width, tokens));
    lines
}

fn tui_box_line(left: char, fill: char, right: char, label: Option<&str>, width: usize) -> String {
    let width = width.max(2);
    let inner = width.saturating_sub(2);
    let mut body = fill.to_string().repeat(inner);
    if let Some(label) = label {
        let label = tui_truncate(label, inner);
        let label_width = tui_visible_width(&label);
        if label_width < inner {
            let start = 1.min(inner.saturating_sub(label_width));
            body = format!(
                "{}{}{}",
                fill.to_string().repeat(start),
                label,
                fill.to_string()
                    .repeat(inner.saturating_sub(start + label_width))
            );
        }
    }
    format!("{left}{body}{right}")
}

fn split_first_char(text: &str) -> (Option<&str>, &str) {
    let mut chars = text.char_indices();
    let Some((_, _)) = chars.next() else {
        return (None, "");
    };
    if let Some((next, _)) = chars.next() {
        (Some(&text[..next]), &text[next..])
    } else {
        (Some(text), "")
    }
}

fn tui_pad_line(line: &str, width: usize) -> String {
    let truncated = tui_truncate(line, width);
    let visible = tui_visible_width(&truncated);
    if visible >= width {
        truncated
    } else {
        format!("{}{}", truncated, " ".repeat(width - visible))
    }
}

fn tui_truncate(line: &str, width: usize) -> String {
    if tui_visible_width(line) <= width {
        return line.to_string();
    }
    let limit = width.saturating_sub(1);
    let mut output = String::new();
    let mut visible = 0;
    let mut chars = line.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            output.push(ch);
            for next in chars.by_ref() {
                output.push(next);
                if next.is_ascii_alphabetic() || next == 'm' {
                    break;
                }
            }
            continue;
        }
        if visible >= limit {
            break;
        }
        output.push(ch);
        visible += 1;
    }
    output.push('…');
    if line.contains("\x1b[") {
        output.push_str("\x1b[0m");
    }
    output
}

fn tui_visible_width(line: &str) -> usize {
    let mut visible = 0;
    let mut chars = line.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            for next in chars.by_ref() {
                if next.is_ascii_alphabetic() || next == 'm' {
                    break;
                }
            }
        } else {
            visible += 1;
        }
    }
    visible
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn slash_palette_renders_scrollable_command_list() {
        let palette = slash_palette_for_buffer("/", 20).expect("slash palette");
        let lines = render_slash_palette(&palette, 72, 5, theme_tokens("plain"));
        assert!(lines.iter().any(|line| line.contains("/")));
        assert!(lines.iter().any(|line| line.contains("of")));
        assert!(lines.iter().any(|line| line.contains("Enter")));
        assert!(lines.len() <= 6);
        for line in lines {
            assert!(tui_visible_width(&line) <= 72, "too wide: {line}");
        }
    }

    #[test]
    fn session_picker_filters_and_renders_width_safe_rows() {
        let items = vec![
            SessionPickerItem {
                id: "thread-1".to_string(),
                title: "Root work".to_string(),
                status: "Active".to_string(),
                cwd: "/repo".to_string(),
                forked_from: None,
                current: false,
            },
            SessionPickerItem {
                id: "thread-2".to_string(),
                title: "Feature branch".to_string(),
                status: "Active".to_string(),
                cwd: "/repo/packages/native".to_string(),
                forked_from: Some("thread-1".to_string()),
                current: true,
            },
        ];
        let filtered = filtered_session_items(&items, "native");
        assert_eq!(filtered.len(), 1);
        assert_eq!(
            selected_session_item(&items, "native", 0).unwrap().id,
            "thread-2"
        );
        let lines = render_sessions_overlay(&items, "native", 0, 74, 20, theme_tokens("plain"));
        assert!(lines.iter().any(|line| line.contains("Sessions")));
        assert!(lines.iter().any(|line| line.contains("Feature branch")));
        assert!(lines.iter().any(|line| line.contains("Enter to select")));
        for line in lines {
            assert!(tui_visible_width(&line) <= 74, "too wide: {line}");
        }
    }

    #[test]
    fn model_picker_filters_roles_and_renders_width_safe_rows() {
        let items = vec![
            ModelPickerItem {
                label: "session model: gpt-fast".to_string(),
                detail: "Set the model for normal executor turns".to_string(),
                action: ModelPickerAction::SelectSession("gpt-fast".to_string()),
                current: true,
            },
            ModelPickerItem {
                label: "role reviewer: gpt-review".to_string(),
                detail: "Use gpt-review for reviewer turns".to_string(),
                action: ModelPickerAction::SelectRole {
                    role: "reviewer".to_string(),
                    model: "gpt-review".to_string(),
                },
                current: false,
            },
            ModelPickerItem {
                label: "role reviewer: inherit".to_string(),
                detail: "Clear override; use gpt-fast".to_string(),
                action: ModelPickerAction::ClearRole {
                    role: "reviewer".to_string(),
                },
                current: false,
            },
        ];
        let filtered = filtered_model_items(&items, "review");
        assert_eq!(filtered.len(), 2);
        assert!(matches!(
            selected_model_item(&items, "gpt-review", 0).unwrap().action,
            ModelPickerAction::SelectRole { .. }
        ));
        let lines = render_models_overlay(&items, "review", 0, 78, 20, theme_tokens("plain"));
        assert!(lines.iter().any(|line| line.contains("Model selector")));
        assert!(lines.iter().any(|line| line.contains("role reviewer")));
        assert!(lines.iter().any(|line| line.contains("Enter to select")));
        for line in lines {
            assert!(tui_visible_width(&line) <= 78, "too wide: {line}");
        }
    }

    #[test]
    fn settings_subpanel_renders_nested_actions_width_safe() {
        let provider_items = provider_settings_panel_items(&ProviderConfig::Mock);
        assert!(provider_items.iter().any(|item| matches!(
            item.action,
            SettingsPanelAction::EditCommand(ref command) if command == "/provider smoke "
        )));
        assert!(provider_items.iter().any(|item| matches!(
            item.action,
            SettingsPanelAction::Command(ref command) if command == "/provider validate"
        )));
        let lines = render_settings_subpanel_overlay(
            SettingsSubpanel::Provider,
            &provider_items,
            0,
            80,
            20,
            theme_tokens("plain"),
        );
        assert!(
            lines
                .iter()
                .any(|line| line.contains("Settings › provider"))
        );
        assert!(lines.iter().any(|line| line.contains("Custom API env")));
        assert!(
            lines
                .iter()
                .any(|line| line.contains("Enter/Space to change"))
        );
        for line in lines {
            assert!(tui_visible_width(&line) <= 80, "too wide: {line}");
        }

        let memory_items = memory_settings_panel_items();
        assert!(
            memory_items
                .iter()
                .any(|item| item.label == "Maintenance apply")
        );
        assert!(memory_items.iter().any(|item| matches!(
            item.action,
            SettingsPanelAction::EditCommand(ref command) if command == "/memory compact "
        )));
    }
}
