# OPPi Rust Runtime JSON-RPC Contract

Status: experimental Stage 5 contract. This document tracks the Rust-owned `oppi-server --stdio` line-delimited JSON-RPC surface so CLI, Pi-package, and future VS Code clients can evolve against the same protocol.

## Transport

- Server command: `oppi-server --stdio` (normally launched through `oppi server --stdio --experimental`).
- Mirror dogfood smoke: `oppi runtime-loop smoke --json` starts `oppi-server --stdio`, creates a thread, records a Pi bridge event, runs an adapter-backed `turn/run-agentic` with multiple Pi tool results, exercises approval resume, cancellation, tool/result pairing error handling, continuation guard abort, and a long `memory/compact` handoff event, reads events/debug metrics, reports per-scenario results plus `bridgeClean` / `bridgeCleanReason`, and shuts the server down.
- Direct-worker smoke: `oppi runtime-worker smoke --json` starts a local mock OpenAI-compatible HTTP endpoint plus `oppi-server --stdio`, runs `turn/run-agentic` with `modelProvider.kind = "openai-compatible"` and `stream: true`, verifies Rust made authorized streamed provider requests, executes a provider-requested Rust tool, continues the provider turn with a `role=tool` result, observes streamed assistant deltas, reads events/debug metrics, reports `workerClean` / `workerCleanReason`, and shuts the server down. It does not require external provider credentials.
- Direct-worker product dogfood: `oppi runtime-worker [run] <prompt>` starts the same stdio server, creates a Rust thread, calls the OpenAI-compatible direct-provider path, prints assistant/tool/event/memory/todo diagnostics, and keeps stable Pi fallback guidance visible when provider auth or `oppi-server` is unavailable. Provider options include `--model`, `--base-url`, `--api-key-env`, `--system`, `--max-output-tokens`, `--no-stream`, `--prompt-variant off|a|b|caveman`, and the explicit dogfood-only approval helper `--auto-approve` / `--approve-all`. Hoppi memory is enabled by default for real provider runs when the optional Hoppi package is installed and memory settings allow it; use `--memory`, `--no-memory`, or `OPPI_RUNTIME_WORKER_MEMORY=auto|on|off` to override per run. The prompt variant follows the same selection semantics as Pi (`--prompt-variant`, `OPPI_SYSTEM_PROMPT_VARIANT`, then stored `oppi.promptVariant`) and appends `promptname_a` or `promptname_b` to the direct-provider system prompt. Native/client hosts can pass `OPPI_RUNTIME_WORKER_FOLLOW_UP_JSON` in the direct-worker CLI path, or the JSON-RPC `followUp` field directly, so Rust owns the hidden follow-up prompt append while clients own busy-Enter queue UI.
- Framing: one JSON-RPC 2.0 request per stdin line, one response per stdout line.
- Request shape:

```json
{"jsonrpc":"2.0","id":"request-id","method":"initialize","params":{"clientName":"client"}}
```

- Response success shape:

```json
{"jsonrpc":"2.0","id":"request-id","result":{}}
```

- Response error shape:

```json
{"jsonrpc":"2.0","id":"request-id","error":{"code":-32000,"message":"...","data":{"code":"thread_not_found","category":"not_found"}}}
```

## Authentication

`initialize` is always allowed. When `OPPI_SERVER_AUTH_TOKEN` is set, all other methods must include `authToken` in `params` with an exact token match.

Executable/sensitive sandbox methods (`sandbox/exec`, `sandbox/windows-wfp-install`) require `OPPI_SERVER_AUTH_TOKEN` to be configured and fail closed when it is absent.

## Initialization and compatibility

### `initialize`

Params:

```ts
type InitializeParams = {
  clientName: string;
  clientVersion?: string;
  protocolVersion?: string;
  clientCapabilities?: string[];
};
```

Result:

```ts
type InitializeResult = {
  protocolVersion: string;
  minProtocolVersion: string;
  protocolCompatible: boolean;
  serverName: "oppi-server";
  serverVersion: string;
  serverCapabilities: string[];
  acceptedClientCapabilities: string[];
};
```

Compatibility rule: old clients may omit `protocolVersion`; otherwise, the client major version must match the server major version and the client minor version must be within the server's supported min/current range.

Current server capabilities include:

- `threads`
- `turns`
- `events`
- `background-turns`
- `tools`
- `approvals`
- `questions`
- `sandbox`
- `agents`
- `memory`
- `todos`
- `mcp`
- `models`
- `direct-provider`
- `openai-compatible-provider`
- `openai-codex-provider`
- `side-questions`
- `persistence-replay`
- `commands`

## Error taxonomy

JSON-RPC protocol errors use standard JSON-RPC numeric codes where practical:

| Code | Meaning |
| ---: | --- |
| `-32700` | parse error |
| `-32601` | method not found |
| `-32602` | invalid params |
| `-32000` | runtime error |
| `-32001` | authentication required |
| `-32020` | Windows WFP install failed |

Runtime errors expose stable machine-readable data:

```ts
type RuntimeErrorData = {
  code: string;
  category:
    | "not_found"
    | "already_exists"
    | "already_resolved"
    | "ownership_mismatch"
    | "terminal_state"
    | "approval_required"
    | "tool_pairing"
    | "event_store"
    | "provider"
    | "invalid_request";
};
```

Specific `code` values are stable within a category, for example `thread_not_found`, `approval_thread_mismatch`, `turn_not_mutable`, and `tool_pairing_error`.

## Core methods

Server lifecycle/observability methods:

- `server/shutdown` — acknowledge shutdown and let the stdio server exit after the response is flushed.
- `runtime/metrics` — return redaction-safe runtime counters for threads, turns, events, approvals/questions, plugins, MCP, models, and agents.
- `debug/bundle` — return a redacted debug bundle with runtime metrics and diagnostics suitable for support triage.

Thread/session methods:

- `thread/start` — create a thread for a project.
- `thread/resume` — resume an existing thread by `threadId`.
- `thread/fork` — fork a thread with an optional title.
- `events/list` — list events after an optional cursor with an optional bounded `limit` (default `1000`, max `5000`).

Turn methods:

- `turn/start` — start a turn and emit the current 11-phase skeleton events.
- `thread/list` — returns persisted/replayed threads for native clients. `oppi-shell` uses it for `/tree`, together with existing `thread/start`, `thread/resume`, and `thread/fork`.
- `turn/run-agentic` — experimental Rust-owned 11-phase loop driver using scripted, adapter-backed, or direct-provider model steps, streaming assistant deltas, per-turn tool definitions, registered/sandboxed tool execution, adapter-provided tool results, bounded continuations, cancellation seams, hook diagnostics, and approval pauses.
- `turn/resume-agentic` — resume an approval-paused or user-input-paused Rust-owned agentic turn with approved tool-call ids or `askUserResponse`, optional per-turn tool definitions, cancellation settings, and continuation model steps.
- `turn/steer` — append steering input to a mutable turn.
- `turn/interrupt` — abort/interruption event for a mutable turn, including approval-paused agentic turns and running background turns. When a background turn owns the runtime lock, the server records a shared interrupt request and waits briefly for the running loop to emit `turnInterrupted`; clients can keep polling `events/list` if the interrupt is still pending at a long provider/tool checkpoint.

Agentic turn params now accept:

- `executionMode` — optional turn execution mode. Omitted/`blocking` preserves the existing request/response behavior. `background` is the first Plan 101 native-shell unblocker: `oppi-server --stdio` returns after the turn has started, mirrors semantic events into a server-side event stream, and lets clients poll `events/list` for live `TurnStarted`, phase, delta, tool, approval/question, completion, interrupt, or abort events while the background worker continues. Same-process approval/question resumes preserve direct-provider transcript snapshots. Across server restarts, the event store replays visible thread/turn/event state and aborts incomplete turns with a restart reason; durable direct-provider transcript replay is explicitly deferred. This is intentionally experimental; the stable blocking path remains the default.
- `followUp` — optional hidden follow-up chain metadata supplied by a host/client when a prompt was queued while an earlier answer was running. Rust appends the private follow-up routing guidance to direct-provider system prompts and emits only a redaction-safe diagnostic (`component=follow-up`, chain id, pending count). Native TUI/VS Code clients still own key routing, queue display, and queued-message restore.
- `sandboxPolicy` — optional turn-level Rust permission/sandbox policy. The direct-worker CLI maps `OPPI_RUNTIME_WORKER_PERMISSION_MODE` or stored `oppi.permissions.mode` (`read-only`, `default`, `auto-review`, `full-access`) into this field, and Rust-owned shell/file tools use it when a tool call does not provide a narrower policy. Read-only mode blocks writes even if a write tool call was approved.
- `askUserResponse` on `turn/resume-agentic` — structured answers for an earlier `oppi__ask_user` tool call. Rust emits `askUserResolved`, observes the answers as the pending tool result, and continues the provider turn.
- `modelSteps[].toolResults` — adapter-provided results keyed by `callId`; omitted calls are executed by Rust tool runners.
- `modelProvider` — direct Rust provider selection. Current slices support OpenAI-compatible chat completions and ChatGPT/Codex subscription responses, with optional SSE streaming plus function-tool calls advertised from the Rust turn tool registry:

```json
{
  "kind": "openai-compatible",
  "model": "gpt-4.1-mini",
  "baseUrl": "https://api.openai.com/v1",
  "apiKeyEnv": "OPENAI_API_KEY",
  "systemPrompt": "You are OPPi.",
  "reasoningEffort": "medium",
  "maxOutputTokens": 512,
  "stream": true
}
```

```json
{
  "kind": "openai-codex",
  "model": "gpt-5.1-codex",
  "systemPrompt": "You are OPPi.",
  "reasoningEffort": "medium",
  "stream": true
}
```

  `apiKeyEnv` names an environment variable visible to `oppi-server`; raw API keys should not be sent over JSON-RPC. If omitted, OPPi checks `OPPI_OPENAI_API_KEY` then `OPENAI_API_KEY`. Explicit `apiKeyEnv` names fail closed unless they are `OPPI_OPENAI_API_KEY`, `OPENAI_API_KEY`, or an `OPPI_*_API_KEY` / OpenAI API-key-shaped variable; this prevents a compromised client from asking the server to read arbitrary environment variables and forward them to a provider endpoint. `kind: "openai-codex"` uses the protected `openai-codex` OAuth credential from the OPPi/Pi auth store (`OPPI_OPENAI_CODEX_AUTH_PATH` override, otherwise `OPPI_AGENT_DIR`/`PI_CODING_AGENT_DIR` `auth.json`) and never accepts raw tokens over JSON-RPC. `reasoningEffort` is optional and is forwarded to OpenAI-compatible providers as `reasoning_effort` and to Codex responses as `reasoning.effort` when not `off`; the CLI maps `/effort`-style `xhigh` to OpenAI-compatible `high` until provider-specific max-effort mapping lands. `modelProvider` cannot be combined with scripted `modelSteps`. When `stream` is true, provider SSE content chunks become separate assistant `ItemDelta` events and streamed function-call fragments are assembled before execution. Provider requests seed the configured system prompt plus compact runtime history from completed user/assistant items and the latest handoff summary. In the CLI direct-worker path, the selected prompt variant is appended before memory, then Hoppi recall is client-hosted: the CLI loads bounded Hoppi startup/task context, appends it to `modelProvider.systemPrompt`, sends `memory/set` status to Rust for observability, and writes a bounded Hoppi turn summary after completion. Provider diagnostics record redacted endpoint origin, status, duration, stream/chunk/tool/history counts, and appear in `debug/bundle`. When `toolDefinitions` or built-in Rust tools are available, OPPi sends broad function schemas, maps provider tool calls back to Rust `ToolCall` events, appends one tool/function result per executed call, and continues the provider turn. Precise per-tool JSON schemas, a generalized Rust memory broker for non-CLI clients, and durable provider/profile storage are still planned for later direct-worker slices. The native shell now has redacted `/provider validate` and opt-in `/provider smoke` for live OpenAI-compatible, Codex, and explicit Meridian validation.
- `toolDefinitions` — per-turn tool definitions, used by the Rust registry to validate Pi/adapter tools without registering them globally and advertised to direct providers as available function tools.
- `cancellation` — deterministic cancellation seam (`beforeModelContinuation` or `toolCallIds`) that records aborted tool/turn events.

Command methods:

- `command/prepare` — expand host slash-command intent into the user prompt that should be sent to the next agent turn. Current Rust-owned prompt surfaces cover `/review`, `/review audit` / `/audit`, `/init`, `/independent`, `/bug-report`, and `/feature-request`. Results include `systemPromptProfile` (`review` or `audit`) when the host must append a matching system prompt profile before the turn; picker UI, autocomplete, stored setting mutation, and editor/dashboard launchers remain client-owned.

Tool methods:

- Built-in direct-worker tools currently include `oppi__echo`, `oppi__todo_write`, `oppi__ask_user`, `oppi__suggest_next_message`, `oppi__oppi_feedback_submit`, `oppi__render_mermaid`, `oppi__shell_exec`, `oppi__shell_task`, `oppi__read_file`, `oppi__search_files`, `oppi__write_file`, and `oppi__edit_file`. `oppi__todo_write` normalizes the full todo list, stores Rust `TodoState`, emits `todosUpdated`, and can be read through `todos/list`. `oppi__ask_user` pauses turns as `waitingForUser` and resumes with `askUserResponse`; `oppi__suggest_next_message` emits `suggestionOffered` without blocking; `oppi__oppi_feedback_submit` writes sanitized local drafts and only submits to an explicitly configured intake endpoint when network policy allows it; `oppi__render_mermaid` provides bounded Rust fallback ASCII rendering and sandbox-checked optional output files; `oppi__shell_exec` can start full-access background tasks and `oppi__shell_task` can list/read/kill them. File tools are text-focused, resolve paths under the project cwd, and run root/protected-path preflight checks through the sandbox policy layer; write/edit require approval by default.
- Image-generation parity remains host-gated: `image_gen` should use a host adapter or approved backend/credential story before Rust advertises it as a built-in direct-worker tool. If a host registers `image_gen` as a per-turn tool, Rust accepts the host-provided `toolResults` path; when no adapter result is supplied, the call fails closed instead of pretending generation succeeded. Dedicated image artifact events/schema are deferred until the execution adapter/backend lands.
- `tool/record` — record a single tool call/result pair.
- `tool/batch` — record an ordered/concurrent tool batch with exact call/result pairing.

Approval/question methods:

- `approval/request`
- `approval/respond`
- `question/request`
- `question/respond`

Plugin/MCP/model methods:

- `plugin/register`
- `mcp/register`
- `mcp/action`
- `model/register`
- `model/select`

Agent and side-question methods:

- `agents/register`
- `agents/list`
- `agents/dispatch`
- `agents/block`
- `agents/complete`
- `side-question/ask`

Memory/todo/bridge methods:

- `memory/set` — records memory backend status such as Hoppi enabled/available/count. The CLI direct-worker path uses this after Hoppi recall so Rust events/debug state show whether memory participated.
- `memory/compact` — records a handoff summary. Params may include `details` with `remainingTodos` and `completedOutcomes`; when omitted, Rust derives those fields from its current `TodoState` so todo-aware compaction can preserve active work plus archived outcomes without client-side event mutation.
- `todos/list` — returns the current Rust `TodoState` updated by `oppi__todo_write`; this is the backend half of `/todos` parity for non-Pi clients. Native command UI remains host-owned: `/todos`, `/permissions`, `/agents`, `/memory`, `/background`, `/prompt-variant`, `/suggest-next`, `/effort`, `/provider`, `/models`, `/resume`, `/new`, `/fork`, `/tree`, and role model controls should render or mutate client-visible state through existing Rust methods/events rather than adding hidden provider-loop behavior.
- `background/list` — lists Rust-owned background shell tasks started by `oppi__shell_exec` with task id, command, cwd, output path, and status.
- `background/read` — params `{ taskId, maxBytes? }`; returns task metadata plus a bounded output tail.
- `background/kill` — params `{ taskId }`; kills a Rust-owned background shell task and returns updated task metadata.
- `pi/bridge-event` — redaction-aware adapter lifecycle events from Pi/TS clients; `/runtime-loop` streams message/tool/update/finalization events here before finalizing the adapter-backed `turn/run-agentic` call.

Sandbox methods:

- `sandbox/status` — inspect current sandbox capability.
- `sandbox/plan` — plan policy enforcement without executing.
- `sandbox/exec` — auth-gated sandboxed execution.
- `sandbox/windows-wfp-status` — inspect Windows WFP readiness.
- `sandbox/windows-wfp-install` — auth-gated WFP filter installation for a dedicated sandbox account. The CLI wrapper `oppi sandbox setup-windows --yes` is the user-facing setup path on Windows: it generates the dedicated account password automatically, creates/updates the local account, calls this RPC to install WFP filters, and persists `OPPI_WINDOWS_SANDBOX_*` env vars for future terminals.

## Runtime-loop dogfood modes

Plan 22 uses this config shape for dogfooding the Rust loop without breaking stable Pi usage. The smoke command now reports a `scenarios` array for dry-run hardening coverage (`bridge-smoke`, `approval-resume`, `cancellation`, `pairing-error`, `guard-abort`, and `long-compaction`):

- `default-with-fallback` (default) — automatically mirror normal Pi turns into Rust while keeping Pi as the primary runtime and visible fallback if `oppi-server` is unavailable.
- `command` — keep normal Pi runtime behavior; `/runtime-loop <prompt>` opt-in mirrors a single Pi turn into Rust.
- `OPPI_RUNTIME_LOOP_MODE=off` or `oppi.runtimeLoop.mode = "off"` — disable `/runtime-loop` mirroring.

`oppi doctor` reports the selected runtime-loop mode, direct-worker readiness, and native Rust shell readiness separately, then suggests `oppi runtime-loop smoke --json` / `oppi runtime-worker smoke --json` when the experimental runtime is unavailable or provider auth is missing. Plan 22's repeated smoke passes and follow-up sanity audit promoted `default-with-fallback` to OPPi's default while keeping stable Pi execution as the primary/fallback path. Plan 23 adds `oppi runtime-worker smoke --json` as the direct-provider regression gate and `oppi runtime-worker <prompt>` as the opt-in product dogfood/default-candidate command: the smoke uses a local mock provider, so a clean result means Rust owned the streamed provider HTTP request/tool-continuation path, not that an external account/model was validated. Plan 24 starts parity by preserving Hoppi in that direct-worker path, then adds prompt A/B overlays, `todo_write`/`todos/list`, follow-up prompt routing, provider env safety, todo-aware `memory/compact` details, turn-level `sandboxPolicy`, `ask_user`, `suggest_next_message`, feedback drafts, `render_mermaid`, initial `shell_task`, host-adapter-first `image_gen` safety, and command prompt expansion for review/audit/init/independent/feedback; remaining slash commands/tools are being ported one at a time.

## Stability notes

- The contract is experimental, but clients should treat `initialize.protocolCompatible=false` as a warning/blocking condition before using advanced methods.
- Runtime invariants reject cross-thread mutations, late terminal-turn mutation, duplicate approval/question resolution, and malformed tool batches before partial mutation.
- Sandbox execution must fail closed when a policy requires OS enforcement that the current platform cannot provide.
- Future stable clients should prefer generated TypeScript types from Rust protocol schemas once the generation pipeline lands.
