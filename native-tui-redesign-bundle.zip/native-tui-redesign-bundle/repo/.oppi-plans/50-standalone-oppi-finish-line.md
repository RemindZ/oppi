# 50 — Standalone OPPi Finish Line

## Goal

This is the active source of truth for the remaining work before Rust/native OPPi can replace normal Pi/OPPi as the day-to-day standalone path.

It consolidates the remaining blockers from archived Plans 99, 100, and 101:

- `completed/99-slashcommand-parity.md` — original normal Pi/OPPi surface parity catalog.
- `completed/100-rust-oppi-standalone-gaps.md` — standalone Rust OPPi gap backlog.
- `completed/101-native-rust-shell.md` — detailed native Rust shell execution plan.

Use this file for new work. Read the archived plans only for history or detailed rationale.

## Current verdict

OPPi now has a real native Rust shell path and can operate experimentally without normal Pi:

```bash
cargo build -p oppi-server -p oppi-shell
oppi tui --experimental
oppi tui smoke --mock --json
```

Normal `oppi` must remain the stable Pi/OPPi path until the default-promotion gate in this plan passes repeatedly and the product decision is explicit.

Important UI honesty: `oppi-shell`/`@oppiai/native` now has a real retained Rust TUI preview using Pi-style synchronized differential rendering, raw key input, themed transcript/status, spinner, editor, docks, an arrow-key settings panel, and native picker/subpanel overlays for sessions, models, theme, permissions, provider, login, and memory. It is **still not full feature parity** with Pi's mature coding CLI/TUI: richer session actions and repeated manual dogfood need more polish before default promotion. Line-mode remains the fallback for pipes and degraded terminals.

## Already landed baseline

Do not redo these unless a remaining item depends on them:

- Rust runtime spine, JSON-RPC server, protocol mirror, debug bundle, runtime metrics, event persistence/replay, and stable error taxonomy.
- Rust-owned 11-phase agentic loop with direct OpenAI-compatible provider turns, streaming, tool-call continuation, continuation guard, same-process approval/ask_user resume, and redacted provider diagnostics.
- Rust-owned tools for `todo_write`, `ask_user`, `suggest_next_message`, `render_mermaid`, `shell_exec`, `shell_task`, file read/search/write/edit, feedback draft/submit path, and host-adapter-first `image_gen` fail-closed behavior.
- Native `oppi-shell` retained TUI preview with line-mode fallback and `/todos`, `/permissions`, approval/deny, `ask_user` answer, follow-up queue, `/again`, `/background`, `/prompt-variant`, `/effort`, `/login`, `/logout`, `/review`, `/audit`, `/init`, `/independent`, `/bug-report`, `/feature-request`, `/agents`, `/memory`, `/theme`, `/model`, `/roles`, `/provider`, `/resume`, `/new`, `/fork`, `/tree`, `/settings`, and `/debug` surfaces.
- Role-scoped model controls exist session-locally for planner/thinking, reviewer, orchestrator, executor/subagent roles.
- Native shell persistence/restart behavior is durable and fail-safe: completed history resumes; incomplete turns are aborted visibly on restart; same-process direct-provider pause resume works.
- Native shell rendering has initial themed markdown/code/diff output, semantic tool result digests, background task tails, artifact path hints, and terminal diagnostics.
- `oppi tui --experimental` launcher, `oppi tui smoke --mock --json`, native-shell CI matrix, and `oppi doctor` shell/protocol/sandbox/provider/terminal diagnostics exist.

## Promotion policy

Default promotion is **blocked** until:

- the automated validation matrix passes repeatedly on clean machines;
- the manual dogfood checklist below is completed with no critical gaps;
- security/degraded-mode messaging is honest about sandbox, background process, network, and provider boundaries;
- the user/product owner explicitly approves making the native/Rust path default.

## User decisions captured for the finish-line push

Captured from product-owner answers after Plan 50 consolidation:

- **Default promotion scope:** promote only after core daily-use gates pass. Image/subagent/memory-broker work may remain explicit limitations only if the core standalone experience is honest and stable.
- **Native UI target:** build toward a retained scrollback TUI with docked components and low flicker, not a full dashboard-first alternate-screen app.
- **Image generation:** implement image generation to match Codex CLI-style behavior as closely as legally and technically practical. Codex CLI is an approved Apache-2.0 reference; prefer a clean OPPi implementation with attribution only if any source-level port is used.
- **Subagents/skills:** target native `AgentTool`/subagent execution in Rust, including policy enforcement and skill injection.
- **Memory:** do not design a broad Rust memory broker first. Build native Hoppi status/settings/dashboard/maintenance UI while keeping the backend client-hosted for now.
- **Auto-review:** implement a narrow Guardian-style reviewer path for protected/risky operations; do not block every ordinary approval on reviewer model work.
- **Background tasks:** must be sandboxed for default promotion. No unrestricted background shell tasks in the default standalone path.
- **Providers:** `/login`/subscription-style auth is the primary desired UX for default OPPi; API-key/env-ref setup is a fallback and automation path. OpenAI-compatible direct API remains supported. Anthropic/Claude subscription support should use an explicit Meridian-style bridge when selected by the user from `/login`, with visible install/start/stop lifecycle and no hidden background spawning.
- **Provider login UX:** native `/login` should become a pickable list like Pi, not a command-only expert surface. First choose `Subscription` vs `API`; then subscription choices should include `Codex (ChatGPT)`, `Claude (Anthropic via Meridian)`, and `Copilot (Microsoft)`. API should guide env-ref/direct-compatible setup. `/login` owns auth/provider setup only; model selection belongs in `/model` or `/settings`, not `/login ... use <model>`.
- **Credentials:** login credentials/tokens belong in the protected OPPi/Pi auth store or a managed provider bridge; environment references remain supported as fallback. Raw secrets do not cross normal JSON-RPC or get stored in ordinary settings.
- **Meridian bridge:** prefer a managed dependency/bridge over copying Meridian internals so OPPi can update with upstream. Meridian install/start must be explicit and visible, run on loopback by default, force Pi/OPPi passthrough/client-owned tools, avoid hidden `npx` fallback, and avoid visible Claude Code command windows except an intentional browser/CLI login step. If a `/login` flow needs installing Meridian or another managed bridge, it must first ask for user approval and show the exact package/action; selecting Claude must not silently install or start anything.
- **Graphify:** add codebase-structure context as a complement to Hoppi memory. Hoppi remains for user requirements/context; Graphify should cover codebase graph/architecture structure through skills plus hook detection/install prompts.
- **Native npm package:** keep `@oppiai/cli` as the stable legacy Pi/OPPi package and add a side-by-side Rust-first package as `@oppiai/native`. To allow both global installs at once, `@oppiai/native` should expose a non-conflicting binary such as `oppi-native` (and maybe `oppi-rs`), not claim the `oppi` bin until an explicit default-promotion/package handoff decision.
- **Provider transcript replay:** not the first blocker after core dogfood, but still a hardening item after the core UI/security smokes.
- **Role profiles:** persisted planner/thinking, reviewer, orchestrator, and executor model controls are required for promotion. Planning/thinking/review can use heavier, more expensive models while execution/subagent/small coding tasks can use cheaper or faster models against a well-structured plan.
- **First execution order:** start with dogfood/failure smokes to reveal real blockers.

## Remaining workstreams

### 1. Default-promotion dogfood and failure-mode gate

Priority: high.

Acceptance:

- [ ] Live configured-provider smoke passes with no secrets in stdout/stderr/debug bundles.
- [ ] Non-trivial repo edit through native shell with file tools and approval.
- [ ] Read-only mode blocks a write attempt visibly.
- [ ] Protected path attempt is denied or requires the correct approval path.
- [ ] Network-disabled turn fails closed for networked actions with clear messaging.
- [ ] `/background` list/read/kill is dogfooded through native shell.
- [ ] Follow-up queue handles at least two queued follow-ups and produces a combined final answer.
- [ ] `ask_user` pause/resume is dogfooded through native shell.
- [ ] Approval pause/resume is dogfooded through native shell.
- [ ] Missing provider auth shows stable fallback guidance without crashing.
- [ ] Missing Hoppi behaves clearly when memory is enabled/auto.
- [ ] Missing image backend keeps `image_gen` fail-closed and visible.
- [ ] Server restart/resume is dogfooded for completed sessions and visible aborted incomplete turns.
- [ ] Terminal restore after abort/panic is checked on Windows and Unix.
- [ ] `oppi doctor --json` remains redacted and reports shell, server, protocol, sandbox, provider, and terminal readiness.

Validation matrix:

```bash
cargo fmt --check
cargo test --workspace
pnpm -r --if-present check
pnpm -r --if-present build
pnpm -r --if-present test
node packages/cli/dist/main.js runtime-loop smoke --json
node packages/cli/dist/main.js runtime-worker smoke --json
node packages/cli/dist/main.js tui smoke --mock --json
node packages/cli/dist/main.js doctor --json
```

### 2. Native UI polish and raw/full-TUI input

Priority: high for default replacement quality.

The first retained/raw Rust TUI slice is landed and usable for dogfood, but normal-Pi replacement quality still needs session/settings navigation polish and repeated manual dogfood. Treat the current native shell as a preview until this section is complete.

Acceptance:

- [x] Implement raw-mode key capture or retained TUI layer without regressing line-mode fallback.
- [ ] Add a real coding-CLI session surface: persistent session list/resume, command palette, selectable settings panels, and arrow-key navigation comparable to normal OPPi/Pi. Current slices: `/settings` opens anchored theme/permissions/model/provider/login/session/memory panels; typing `/` opens a stable OPPi-visible command palette below the editor with five visible rows, fuzzy search, ↑↓/PgUp/PgDn/Home/End selection, Tab completion, Escape cancel, Enter-to-run for complete selections, and contextual argument/subcommand hints; `/tree`, `/sessions`, or bare `/resume` opens an arrow-key session picker with type-to-filter and Enter-to-resume; Ctrl+L or `/model`/`/models`/`/roles`/settings → Model opens an arrow-key model/role selector with type-to-filter and Enter-to-apply; Ctrl+P/Ctrl+Shift+P cycle models and Shift+Tab cycles effort; bare `/theme`, `/permissions`, `/provider`, `/login`, and `/memory` or the matching settings rows open anchored nested settings subpanels with selectable actions, including a pickable `/login` Subscription/API flow. Richer session browser actions such as rename/delete/tree folding remain pending.
- [x] Busy Enter routes to the follow-up queue in the real interactive UI.
- [x] Alt+Enter queues a follow-up explicitly where terminals support it.
- [x] Ctrl+Enter sends steering input to the active turn where supported.
- [x] Alt+Up restores queued follow-up messages into the editor where supported.
- [x] Shift+Enter multiline input, Escape interrupt/clear, Ctrl+D safe exit, and Ctrl+C behavior work in raw mode.
- [x] Footer/status widgets remain concise: provider/model role, permission mode, memory, todo count, queued follow-ups, and diagnostics.
- [x] Docked panels for todos, approvals, questions, background tasks, and suggestions are width-safe and non-flickery.
- [ ] Terminal capability diagnostics explain degraded keybindings and color fallback.
- [ ] Snapshot or golden-output tests cover narrow/normal/wide widths and dark/light/plain themes.

### 3. Provider, role-profile, and transcript hardening

Priority: high.

Acceptance:

- [ ] Persist independently configurable role-scoped model profiles, especially planner/thinking versus executor/small-task models, instead of keeping them session-local only.
- [ ] Apply planner/reviewer/orchestrator/executor role selection consistently to command wrappers, future orchestration, and future subagent runs.
- [ ] `/agents` shows which role/model/effort a run will use before dispatch.
- [ ] `/review` and `/audit` default to reviewer role; `/independent` uses planner/orchestrator for planning and executor for steps once native splitting exists.
- [ ] Provider status/validation remains explicit and redacted; no hidden paid/live calls.
- [x] Replace command-only native `/login` with a pickable flow: `Subscription` vs `API`, then `Codex (ChatGPT)`, `Claude (Anthropic via Meridian)`, `Copilot (Microsoft)`, or API env-ref/direct-compatible setup.
- [x] Keep `/login` scoped to auth/provider/bridge setup only; model choice and role model profiles stay in `/model` and future `/settings`.
- [x] Require explicit user approval before `/login` installs managed bridge dependencies such as Meridian; show the exact package/action and preserve no-hidden-spawn guarantees.
- [x] Add native `/login` provider setup surface and make it the primary default UX; API keys/env refs remain fallback. ChatGPT/Codex now has native browser OAuth and protected auth-store token use for the Rust provider; Copilot/Gemini/Antigravity remain delegated to stable Pi `/login` until native OAuth ownership is explicitly needed.
- [x] Keep OpenAI-compatible as the primary direct API path and add Anthropic/Claude subscription support through an explicit user-selected Meridian-style bridge or direct API equivalent.
- [x] Do not spawn Meridian, Anthropic subscription proxies, `npx`, or external provider brokers implicitly; `/login subscription claude` offers approval-gated install plus visible start/use/stop commands.
- [ ] Persist direct-provider resume snapshots so approval/ask_user paused turns can resume across server restarts without losing provider transcript state.
- [ ] Add tests for persisted provider transcript replay and visible fail-safe fallback when replay is impossible.

### 4. Image generation and artifact tracking

Priority: medium-high.

Current policy: Rust must not advertise a built-in `image_gen` executor until an approved backend/adapter exists. Adapter-provided results are accepted; missing adapter results fail closed.

Acceptance:

- [ ] Implement Codex CLI-style image generation behavior as a clean OPPi-native path or approved adapter, with attribution if any Apache-2.0 source-level port is used.
- [ ] Define credential and network policy for the chosen backend/adapter.
- [ ] Keep transparent-background confirmation policy explicit when backend/model choice requires it.
- [ ] Add artifact metadata/events with output path, mime type, dimensions when known, source image/mask metadata, backend label, and redacted diagnostics.
- [ ] Render artifact previews/hints in native shell without assuming image backend availability.
- [ ] Tests cover artifact paths, overwrite handling, credential failure, network-disabled failure, backend-missing failure, and transparent-background confirmation.

### 5. True subagents and skill injection

Priority: medium-high.

Current state: agent registry/lifecycle exists; true nested execution and skill catalog parity do not.

Acceptance:

- [ ] Implement native `AgentTool`/subagent execution semantics in Rust.
- [ ] Enforce tool allow/deny lists, permission mode, memory mode, role-scoped model/effort, background flag, isolation, color, skills, and max-turns on dispatch.
- [ ] Stream agent run output/blockers back into the parent turn/UI.
- [ ] Add markdown agent import/export parity for project/user definitions.
- [ ] Implement skill discovery/injection for built-ins (`imagegen`, `independent`, `mermaid-diagrams`) and user-installed skills.
- [ ] Inject skills only when relevant, with deterministic source/priority rules.
- [ ] Tests cover agent shadowing, built-in disable flag, project/user imports, blocked/completed lifecycle, and skill selection.

### 6. Sandbox, permissions, auto-review, and background hardening

Priority: high for security claims.

Current state: Rust enforces initial policy for Rust-owned tools. Windows setup exists. More hardening is required before default replacement claims.

Acceptance:

- [ ] Persist native permission mode setting mutation and show source/precedence.
- [ ] Add per-tool approval policy where the runtime, not only the prompt, decides whether approval is required.
- [ ] Add a narrow Guardian-style auto-review reviewer process for protected/risky tool calls.
- [ ] Expand OS sandbox enforcement coverage and fail-closed diagnostics for unavailable adapters.
- [ ] Sandboxed background tasks instead of full-access/unrestricted background shell tasks; default promotion requires this.
- [ ] Protected-file handling is consistently enforced for shell, file tools, feedback drafts, image outputs, and future adapters.
- [ ] Tests cover read-only/default/auto-review/full-access, network disabled/ask/enabled, protected paths, and background task policy.

### 7. Memory broker beyond CLI-hosted Hoppi

Priority: medium.

Current state: CLI-hosted Hoppi bridge works; non-CLI memory broker is future work.

Acceptance:

- [ ] Keep Hoppi backend client-hosted for now; do not design a broad Rust memory broker before a second host needs it.
- [ ] Native Hoppi memory status/dashboard/settings UI works for non-Pi hosts.
- [ ] Explicit maintenance trigger UI exists; no hidden idle/deep model sessions.
- [ ] Memory recall/write summaries are bounded, redacted, and observable through Rust events/debug state.
- [ ] Add a future Hoppi/OPPi system-scope recurring-task mining lane: consolidation records cross-project recurring task candidates separately from project memories, then proposes user-approved skill creation when patterns repeat often, using relevant prompts, `ask_user` answers, outcomes, and related memories as draft context.
- [ ] Ensure memory cleanup honors Hippo/Hoppi retrieval telemetry: repeated retrieval/use strengthens memories and should protect or bias them during cleanup instead of being ignored or pruned as stale noise.
- [ ] Tests cover missing Hoppi, disabled memory, recall failure, write failure, status propagation, redaction, separation between project memories and system-scope recurring-task candidates, and cleanup behavior for retrieval-strengthened memories.

### 8. Command parity cleanup and client convenience UX

Priority: medium.

Many commands have initial native shell support. Remaining work is mostly polish, persistence, and parity with normal Pi/OPPi convenience flows.

Acceptance:

- [ ] `/todos` supports client-only convenience actions such as clear/done without changing `todo_write`'s model-owned full-list contract.
- [ ] `/suggest-next` can display, accept, clear, and debug ghost suggestions from `suggestionOffered` events.
- [ ] Structured question/`ask_user` countdown timer adds 30 seconds every time the user answers a question, so multi-question flows do not feel like speedruns.
- [ ] `/effort` becomes model-aware and stores per-session/default effort settings.
- [ ] `/prompt-variant` persists stored `oppi.promptVariant`, not only session-local state.
- [ ] `/memory` dashboard/settings/maintenance stubs become real host/native affordances where supported.
- [ ] `/background` renders richer progress/status events and survives or clearly resets across process boundaries.
- [x] Native slash-command palette/autocomplete exists for the whole command list, including `/review`, `/audit`, `/init`, `/independent`, `/bug-report`, and `/feature-request`; richer command-specific review/picker flows can still be added later where useful.
- [ ] `/usage`/`/stats` remains client-owned unless a provider-neutral runtime usage surface is designed.
- [ ] `/exit` preserves safe shutdown and terminal restoration in all shell modes.

### 9. Prompt catalog, variants, and skills consistency

Priority: medium.

Acceptance:

- [ ] Apply selected prompt variant consistently to ported command/user prompts, reviewer surfaces, memory maintenance prompts, and compaction prompts where applicable.
- [ ] Keep runtime prompt changes mirrored in `systemprompts/`.
- [ ] Ensure feature-routing guidance remains present in direct-worker/native turns without duplicating noisy text.
- [ ] Ensure skill instructions are injected only when relevant and with clear provenance.

### 10. Graphify codebase-structure context

Priority: medium.

Acceptance:

- [x] Audit Graphify docs/license/install model before implementation.
- [x] Add a Graphify skill so the model can use codebase graph context when architecture/dependency questions or repo-wide navigation tasks make it relevant.
- [x] Add hook/status detection that checks whether Graphify is installed/configured for the project.
- [x] If missing, propose installation/configuration to the user instead of installing silently.
- [x] Keep Graphify separate from Hoppi: memories capture user requirements and durable context; Graphify captures codebase structure and dependency relationships.
- [x] Tests cover skill relevance, missing-hook guidance, installed-hook detection, and redacted diagnostics.

### 11. Side-by-side native npm package

Priority: medium-high for native dogfood rollout.

Acceptance:

- [x] Add `packages/native` published as `@oppiai/native`.
- [x] Keep `@oppiai/cli` as the legacy/stable Pi-backed package.
- [x] Use a non-conflicting global bin such as `oppi-native` so users can install both packages side by side.
- [x] Package or fetch platform-specific `oppi-server`/`oppi-shell` binaries without requiring users to build Rust locally for normal installs.
- [x] Preserve `oppi` as the legacy bin until default promotion is explicitly approved.
- [x] Document install examples: `npm i -g @oppiai/cli` for legacy and `npm i -g @oppiai/native` for Rust-first preview.
- [x] Add smoke tests that install/run the native package launcher without breaking `@oppiai/cli`.

## 20-step execution todo sequence

Use this as the working order for future implementation sessions. Keep at most one or two steps in progress at a time.

1. Run the full baseline validation matrix and record failures/noisy diagnostics in this plan.
2. Add automated native shell dogfood harnesses for live-provider, repo-edit, approvals, `ask_user`, follow-up queue, and `/background` scenarios where practical.
3. Run/record live configured-provider smoke with redaction checks.
4. Dogfood a non-trivial repo edit through native shell with file tools and approval.
5. Add failure-mode smokes for read-only writes, protected paths, network-disabled actions, missing auth, missing Hoppi, missing image backend, and restart/resume.
6. Implement sandboxed background task execution and block/degrade visibly when sandboxing is unavailable.
7. Polish `/background` progress/status rendering and task read/kill UX on top of the sandboxed implementation.
8. Persist role-scoped model profiles for planner/thinking, reviewer, orchestrator, executor, and subagent roles.
9. Wire role profiles consistently through `/review`, `/audit`, `/independent`, `/agents`, normal executor turns, and debug/status output.
10. Add provider status/validation hardening for OpenAI-compatible primary and evaluate Anthropic via explicit translation-compatible/direct API path.
11. Build provider transcript replay snapshots for paused approval/ask_user turns after core dogfood blockers are understood.
12. Implement retained scrollback TUI foundation with component invalidation, docked panels, footer/status widgets, and line-mode fallback.
13. Implement raw keybindings: Enter, Shift+Enter, busy Enter queueing, Alt+Enter, Ctrl+Enter steering, Alt+Up restore, Escape, Ctrl+C, and Ctrl+D.
14. Add width/theme snapshots for transcript, docks, tool blocks, approval/question panels, and footer/status rendering.
15. Implement Codex CLI-style `image_gen` behavior as a clean OPPi-native backend/adapter with env-ref credentials and network policy.
16. Add artifact metadata/events, native artifact rendering hints, and image failure/overwrite/transparent-background tests.
17. Implement native `AgentTool`/subagent execution with tool/memory/model/effort/background/isolation policy enforcement.
18. Implement skill discovery/injection for built-ins and user-installed skills with deterministic source/priority rules.
19. Replace native Hoppi dashboard/settings/maintenance stubs with real client-hosted Hoppi UI controls and redacted status events.
20. Re-run the full validation matrix repeatedly, complete the manual dogfood checklist, and make the explicit default-promotion decision.
21. Add `/login` auth parity with subscription-first UX and managed Meridian Anthropic setup.
22. Add Graphify skill/hook integration as a codebase-structure companion to Hoppi memory.
23. Add `@oppiai/native` side-by-side npm package for the Rust-first path while keeping `@oppiai/cli` as legacy/stable. ✅
24. Polish native `/login` into the Pi-like pickable auth flow with subscription/API branches, approval-gated bridge installation, and model choice delegated to `/model`/`/settings`.
25. Replace the line-mode-first native shell with a retained Rust TUI using Pi-style synchronized differential rendering, raw input, spinner/status styling, docked panels, editor, and first settings panel.
26. Add a Pi-like slash command palette: full command list on `/`, typed filtering, ↑↓ navigation, Enter insertion, and next-argument/subcommand hints.

## Promotion decision log

Use this section to record clean dogfood runs and product decisions.

- 2026-05-02: Native shell exists and packaging/smoke gate is wired. Default promotion is **not approved**; normal `oppi` remains stable Pi/OPPi.
- 2026-05-03: Baseline validation matrix passed from repo root on Windows: `cargo fmt --check`, `cargo test --workspace`, `pnpm -r --if-present check`, `pnpm -r --if-present build`, `pnpm -r --if-present test`, `node packages/cli/dist/main.js runtime-loop smoke --json`, `node packages/cli/dist/main.js runtime-worker smoke --json`, `node packages/cli/dist/main.js tui smoke --mock --json`, and `node packages/cli/dist/main.js doctor --json`. Recorded gaps: live direct-provider auth is not configured for real provider smoke; Windows disabled-network sandbox requires elevated `oppi sandbox setup-windows --yes`/WFP setup before live disabled-network dogfood.
- 2026-05-03: Added automated native shell dogfood harness `oppi tui dogfood --mock --json`. It drives the real native shell through repo-edit approval/resume, `ask_user` answer plus two queued follow-ups, and `/background` list/read/kill against a background shell task. The repo-edit scenario wrote `docs/native-shell-dogfood.md` through Rust-owned `write_file` after `/approve`. Targeted validation passed: `cargo fmt --check`, `cargo build -p oppi-shell`, `cargo test -p oppi-shell`, `pnpm --filter @oppiai/cli test`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Extended `oppi tui dogfood --mock --json` with failure-mode scenarios for read-only write denial, protected-path denial, network-disabled shell denial, and missing `image_gen` backend fail-closed behavior. Added CLI coverage for missing Hoppi degradation; existing runtime-worker coverage verifies missing provider auth fallback; existing server persistence tests cover restart/resume fail-safe behavior.
- 2026-05-03: Hardened background shell tasks to require sandboxed background spawning instead of unrestricted `Command::spawn`. Supported POSIX adapters use the sandbox plan wrapper with OS enforcement required; Windows restricted-token background spawning now fails closed with a visible `sandbox-unavailable-denied` dogfood result until a true background adapter is implemented. Targeted validation passed: `cargo test -p oppi-core -p oppi-server -p oppi-sandbox`, `pnpm --filter @oppiai/cli test`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Polished `/background` task UX: protocol task info now carries start/finish times, exit code, and output byte count; native shell list/read/kill renders status counts, durations, log paths, tail/truncation hints, and process-local reset guidance; `/background read` and `/background kill` support `latest`/implicit latest selection where safe; killing terminal tasks no longer rewrites them to `killed`. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-shell -p oppi-server`, `pnpm --filter @oppiai/cli test`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Persisted native shell role-scoped model profiles under `oppi.roleModels` in the OPPi agent `settings.json` (or `OPPI_ROLE_PROFILES_PATH` for tests). `/model role`/`/roles` now load and save planner/thinking/reviewer/orchestrator/executor/subagent profiles across shell restarts, preserve unrelated settings, expose the role profile source in model/debug output, and the `oppi tui` launcher now passes `OPPI_AGENT_DIR`/`PI_CODING_AGENT_DIR` into `oppi-shell`. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `pnpm --filter @oppiai/cli test`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Wired role profiles through native command and agent surfaces. Command wrappers now pass role/model/effort context to `command/prepare`, print the effective role profile before running, and still route `/review`/`/audit` to reviewer, `/init` to planner, `/independent` to orchestrator, and feedback commands to planner. `/agents list` and `/agents dispatch` show the subagent role profile before dispatch; agent dispatch/run protocol now carries role/model/effort metadata for future native subagent execution. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-shell -p oppi-server`, `pnpm --filter @oppiai/cli test`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Hardened native provider status/validation messaging and recorded Anthropic evaluation. `/provider status` and `/provider validate` now state that they are local/redacted with no live calls, `/provider smoke` remains the explicit live-call path, `/provider anthropic` explains the safe current stance, and provider policy explicitly forbids hidden Meridian, `npx`, Anthropic subscription proxy, external broker, or credential-helper spawning. Anthropic remains future direct-API work or a user-owned OpenAI-compatible translation endpoint. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-shell -p oppi-server`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Added provider transcript replay snapshots for direct-provider paused turns. The runtime emits/persists `providerTranscriptSnapshot` events before approval/ask_user pauses, rehydrates OpenAI-compatible provider messages on event replay, reconstructs ask_user tool calls from snapshots, and skips crash-recovery aborts for replayable waiting turns. Tests now cover approval and ask_user direct-provider resume after replay/restart and terminal fail-safe still aborts non-replayable incomplete turns. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-server`, `cargo test -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Implemented the retained scrollback TUI foundation while preserving line-mode fallback. `oppi-shell` now retains rendered transcript lines across event replay, tracks dirty/invalidated dock components, renders width-safe dock/footer panels, exposes a `/ui [width height]` retained-frame preview/debug surface, and includes background/todo/approval/question/suggestion/footer state in the dock model. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Added raw keybinding and steering/follow-up controls. `oppi-shell --raw` now runs a byte-parser input loop that polls turn events concurrently, routes busy Enter to the follow-up queue, supports Alt+Enter explicit queue, Ctrl+Enter `/steer`, Alt+Up queued-message restore, Shift+Enter multiline, Escape/Ctrl+C interrupt-or-clear, Ctrl+D safe exit, and `/keys`/`/steer`/`/interrupt` line-mode fallbacks with terminal degradation diagnostics. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-shell`, a piped `oppi-shell --mock --raw` smoke, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Added width/theme UI snapshot coverage for the retained TUI. `oppi-shell` now has golden snapshot files for narrow/normal/wide retained frames covering transcript tails, tool/artifact blocks, todos, approval/question/background/suggestion docks, and footer/status truncation, plus a deterministic palette snapshot for plain/light/dark/oppi theme tokens. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Implemented the first clean native `image_gen` backend path. Rust now executes `image_gen` through an explicit OpenAI Images-compatible endpoint (`OPPI_IMAGE_API_BASE_URL`/`OPPI_OPENAI_BASE_URL` or `baseUrl`) using env-reference credentials only (`OPPI_IMAGE_API_KEY`, `OPPI_OPENAI_API_KEY`, `OPENAI_API_KEY`, or approved `apiKeyEnv`), enforces turn network policy before live calls, writes b64 image data to sandbox-checked output paths, preserves host-adapter-provided results, and keeps missing backend credentials fail-closed. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-core -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Added artifact metadata/events and expanded image tests. Protocol now includes `artifactCreated` metadata with output path, MIME, dimensions when known, source image/mask inputs, backend/model, byte count, and redacted diagnostics; the runtime emits artifact events from JSON tool outputs; the shell renders artifact events with concise hints. Image coverage now includes native b64 output writing, artifact metadata, missing credentials/backend, network-disabled failure, overwrite refusal, and transparent-background confirmation/model enforcement. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Implemented native `AgentTool`/subagent execution semantics in Rust. The default runtime tool registry now exposes `oppi.AgentTool`, nested subagent turns carry `parentTurnId`, agent lifecycle events stream back through the parent tool call, and `AgentRun` records role/model/effort, background, permission, memory, allow/deny tool policy, isolation/color, requested skills, and max-turn metadata. Dispatch enforces agent/call permission floors, restricted child tool registries, parent sandbox/network floors, model/effort/system-prompt propagation, and blocked/completed lifecycle updates when child turns pause or finish. Native shell rendering now shows agent start/block/complete lines with policy hints. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-server -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Implemented native skill discovery and relevant skill injection. Rust now discovers built-in skills (`imagegen`, `independent`, `mermaid-diagrams`), user skill roots, and project `.pi/skills`/`.agents/skills` roots with deterministic priority (project > user > built-in), exposes `skills/list` plus native `/skills`, resolves shadowed definitions, and injects bounded skill instructions only when the current direct-provider turn or subagent request matches deterministic relevance rules or explicit skill names. Tests cover built-in/project discovery, shadowing, direct-provider prompt injection, protocol serialization, and JSON-RPC listing. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-server -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Replaced native Hoppi memory stubs with explicit client-hosted UI controls. Rust now exposes `memory/control` for dashboard/settings/maintenance actions, returns safe command controls, emits redacted `memory control action` diagnostics, and makes maintenance preview/apply explicit without starting hidden idle/deep model sessions. Native `/memory dashboard`, `/memory settings`, and `/memory maintenance [dry-run|apply]` render real status/control panels instead of future-work stubs while keeping Hoppi backend ownership client-hosted. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-protocol -p oppi-core -p oppi-server -p oppi-shell`, and `node packages/cli/dist/main.js tui dogfood --mock --json`.
- 2026-05-03: Re-ran the full Plan 50 validation matrix after the final native skill/Hoppi UI work: `cargo fmt --check`, `cargo test --workspace`, `pnpm -r --if-present check`, `pnpm -r --if-present build`, `pnpm -r --if-present test`, `node packages/cli/dist/main.js runtime-loop smoke --json`, `node packages/cli/dist/main.js runtime-worker smoke --json`, `node packages/cli/dist/main.js tui smoke --mock --json`, and `node packages/cli/dist/main.js doctor --json` all passed. Also re-ran `node packages/cli/dist/main.js tui dogfood --mock --json`; repo-edit approval, ask_user/follow-up queue, background sandbox degrade, read-only/protected/network denials, and missing image backend fail-closed scenarios passed. Default promotion is **not approved yet**: live configured-provider redaction smoke remains blocked until real provider env credentials are configured, Windows disabled-network sandbox still warns until elevated WFP setup is completed, and product-owner approval is still required before making the native/Rust path the default.
- 2026-05-03: Product-owner provider-auth decision update: native/default OPPi should prefer `/login` and subscription-style provider auth, with API keys/env refs as fallback. Anthropic/Claude subscription support should reuse the existing Meridian direction: if the user chooses Anthropic/Claude login, OPPi can offer to install/start Meridian with explicit consent and visible lifecycle controls, rather than requiring manual env credentials or hidden proxy spawning. Native provider policy must be updated accordingly before default promotion.
- 2026-05-03: Audited current Meridian integration and upstream package docs/metadata. Meridian is MIT (`@rynfar/meridian` 1.41.1) and is designed as a local Anthropic/OpenAI-compatible bridge around the official Claude Code SDK `query()` path. For Pi/OPPi it should run with `x-meridian-agent: pi`, loopback base URL, and passthrough/client-owned tool execution. Updated the Pi-package bridge toward the managed-dependency policy: `/meridian install` installs the package into OPPi-managed packages with explicit confirmation, embedded managed import is preferred, `MERIDIAN_DEFAULT_AGENT=pi` and `MERIDIAN_PASSTHROUGH=1` are set for OPPi-started instances, and `npx @rynfar/meridian` is disabled unless `OPPI_MERIDIAN_ALLOW_NPX=1` is explicitly set. Native provider policy text now reflects `/login`-first auth plus explicit managed Meridian setup.
- 2026-05-03: Added Graphify as a planned codebase-structure context companion to Hoppi memory. Implementation should add a Graphify skill, hook/status detection, and user-approved install/configuration prompts; Graphify should represent repo structure/dependencies while Hoppi preserves user requirements and durable memory.
- 2026-05-03: Product-owner packaging decision: keep npm `@oppiai/cli` available as the stable/legacy Pi-backed package and introduce the native/Rust-first path as a separate `@oppiai/native` package. To preserve side-by-side installs, the native package should use a non-conflicting bin like `oppi-native` until explicit default-promotion/package handoff approval.
- 2026-05-03: Fixed a likely Windows global-install silent no-op in `@oppiai/cli`: the CLI entrypoint previously compared `process.argv[1]` to `__filename` with plain `resolve()`, which can fail under npm shims/junctions/case differences and cause `node dist/main.js --version`/`oppi.cmd --version` to import then exit without running. The entrypoint now compares canonical `realpathSync()` paths with Windows case-folding, and CLI tests cover resolved entrypoint paths. Validation passed: `pnpm --filter @oppiai/cli test`.
- 2026-05-03: Added native shell `/login` and `/logout` provider setup. `/login openai env <ENV>` configures the OpenAI-compatible fallback through env references only; `/login anthropic status|install|start|use [model]|stop` exposes an explicit managed Meridian Claude bridge with visible lifecycle, no hidden `npx`, no hidden proxy spawning, loopback-only placeholder auth, `MERIDIAN_DEFAULT_AGENT=pi`, and `MERIDIAN_PASSTHROUGH=1`. Core direct-provider auth now allows the placeholder `OPPI_MERIDIAN_API_KEY` only for loopback Meridian-style endpoints; remote endpoints still require real env credentials. ChatGPT/Copilot/Gemini/Antigravity native OAuth remains delegated to stable Pi `/login` until native token-store ownership is explicitly needed. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-core -p oppi-shell`, `cargo build -p oppi-shell`, and a piped `/login anthropic use` + `/provider validate` shell smoke.
- 2026-05-03: Implemented Graphify codebase-structure context integration. Audited npm candidates and selected `graphifyy`/`github.com/rhanka/graphify` as the relevant maintained MIT Graphify package (`graphify` npm was an unrelated Apache-2.0 random graph generator; `graphify-pi` is MIT prior art for Pi-style graph guidance). Added built-in `graphify` skill to the Pi package and Rust skill injector, with relevance triggers for architecture, dependency, repo-wide, blast-radius, and codebase-graph tasks. Added native `/graphify status|commands|install` client detection for `.graphify/`, legacy `graphify-out/`, graph artifacts, stale `needs_update`, config files, and CLI presence; missing setup prints user-approved install/config guidance without running package install or hook mutation. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-core -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, and a piped `/skills` + `/graphify status` + `/graphify commands` shell smoke.
- 2026-05-03: Added the side-by-side Rust-first npm package `packages/native` as `@oppiai/native@0.2.11`. It installs non-conflicting `oppi-native` and `oppi-rs` bins while `@oppiai/cli` keeps the legacy/stable `oppi` bin, resolves explicit env overrides, bundled `bin/<platform>-<arch>`/`prebuilds`, optional platform packages, and local Cargo targets, and includes a prepack `build:binaries` script that copies release `oppi-server`/`oppi-shell` binaries into the npm package without any install-time Rust compile step. Docs now show stable vs native-preview global install examples. Validation passed: `pnpm --filter @oppiai/native test`, `pnpm --filter @oppiai/cli test`, `pnpm -r --if-present build`, `pnpm --filter @oppiai/native build:binaries`, `node packages/native/dist/main.js doctor --json`, and `node packages/native/dist/main.js smoke --mock --json` against packaged binaries.
- 2026-05-03: Polished native `/login` into a Pi-like picker. `/login` now opens `Subscription` vs `API`; subscription offers Codex (ChatGPT), Claude (Anthropic via Meridian), and Copilot (Microsoft), while API routes OpenAI-compatible env-ref setup. Claude/Meridian install now requires explicit approval (`yes` in the picker or `--yes`), `/login ... use <model>` is rejected, and model selection is delegated to `/model`/role profiles. Added `scripts/rust-dev-startup.ps1` for local Rust OPPi dev startup with `--smoke`, `--no-build`, and `--real`. Validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, a piped `/login` picker/model-control smoke, and `powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts/rust-dev-startup.ps1 --smoke --no-build`.
- 2026-05-03: Started the real native Rust TUI parity path. Added a `crossterm` raw-input retained TUI for `oppi-shell` with Pi-style synchronized output (`CSI ?2026`), differential redraws, themed transcript/status, spinner, editor with cursor/backspace/history/multiline, docked panels, and Ctrl+P or `/settings` arrow-key settings panel for theme/permissions/model/provider/login/session/memory shortcuts. Interactive terminals now default to the retained TUI; pipes/non-TTY use line-mode fallback and `--no-tui` forces it. `scripts/rust-dev-startup.ps1` now points the native launcher at the freshly built debug/release binaries so dev startup actually runs the just-built Rust TUI. Validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, `pnpm --filter @oppiai/native test`, `node packages/native/dist/main.js smoke --mock --json`, and debug-binary native smoke via `OPPI_NATIVE_SHELL_BIN=target/debug/oppi-shell.exe OPPI_NATIVE_SERVER_BIN=target/debug/oppi-server.exe node packages/native/dist/main.js smoke --mock --json`.
- 2026-05-03: Responded to product-owner feedback that native slash commands were still far from Pi/PyNative. Added a shared slash-command registry and help text, `/commands` alias, full scrollable TUI command palette when typing `/`, typed filtering, ↑↓ selection, Enter-to-insert behavior, and next-argument/subcommand suggestions for provider/login/model/roles/permissions/theme/prompt-variant/effort/background/memory/agents/graphify and command-wrapper flows. `/keys` now documents slash palette controls, and line-mode `/help` prints the full list instead of one unreadable long line. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, and a line fallback `/commands` smoke.
- 2026-05-03: Continued native command-palette polish toward Pi behavior. Palette navigation now supports Tab completion, PgUp/PgDn/Home/End, Escape/Ctrl+C cancel without clearing the editor, fuzzy command search by description/usage (for example `/auth` finds `/login`), and Enter-to-run for complete selected commands/arguments while keeping placeholders as editable completions. Contextual hints now include known model IDs, pending `ask_user` answer options, and current theme/permission markers. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, updated `/keys` + `/commands` line fallback smoke, and debug native package smoke.
- 2026-05-03: Added the first Pi-like native session picker. In the retained TUI, Ctrl+P settings → Sessions, `/tree`, `/sessions`, or bare `/resume` opens a selectable sessions overlay backed by `thread/list`, with current-session marker, title/id/status/path/fork details, type-to-filter, ↑↓/PgUp/PgDn/Home/End navigation, Enter-to-resume via `thread/resume`, and Escape/Ctrl+C close. Line fallback keeps `/sessions` as a text tree alias. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, `/sessions` line fallback smoke, and debug native package smoke.
- 2026-05-03: Added a Pi-like native model/role selector overlay. In retained TUI, Ctrl+P settings → Model, `/model`, `/models`, `/roles`, or `/role-model` opens a selectable model panel backed by `model/list` and known role profiles. Rows cover session model selection, per-role model overrides, and role inherit/clear actions with current markers, type-to-filter, ↑↓/PgUp/PgDn/Home/End navigation, Enter-to-apply, persisted role profile writes, and Escape/Ctrl+C close. Line fallback `/model` behavior is unchanged. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, `/model` line fallback smoke, and debug native package smoke.
- 2026-05-03: Turned root settings shortcuts into real nested native settings subpanels. In retained TUI, settings → Theme/Permissions/Provider/Login/Memory and bare `/theme`, `/permissions`, `/provider`, `/login`, or `/memory` open selectable overlays with ↑↓/PgUp/PgDn navigation, Enter-to-apply/open, Backspace-to-root, and Escape close. Theme and permissions rows apply directly through existing commands; provider/login panels expose redacted status/validate/policy/env-ref/Meridian actions while inserting live smoke/custom env/base URL commands for explicit review; memory exposes status/on/off/dashboard/settings/maintenance/compact actions. Slash command completion now inserts bare picker commands for native panels, so Enter opens the panel and typing a trailing space still shows argument suggestions. Line fallback commands remain unchanged. Targeted validation passed: `cargo fmt`, `cargo test -p oppi-shell`, `cargo build -p oppi-server -p oppi-shell`, settings-related line fallback smoke, and debug native package smoke.
- 2026-05-03: Tightened native TUI parity against stable OPPi/Pi reference styling. Ctrl+P no longer opens settings; native shortcuts now align with the stable model/thinking/follow-up set (Ctrl+L model selector, Ctrl+P/Ctrl+Shift+P model cycle, Shift+Tab effort cycle, Alt+Enter/Alt+Up follow-up queue). The default slash palette/help now filters to the stable OPPi-visible command set while keeping internal/dev commands direct-typed; slash autocomplete is anchored below the editor and capped to five rows. Settings, sessions, models, and login panels now render in the frame flow above the editor instead of floating centered boxes, use Pi-like arrow/current markers and dim detail text, and `/login` is a fully arrow-key navigable Subscription/API flow with nested Claude/Meridian actions. The footer now shows ready/running status, provider/model/permission/todo/queue state, and stable Alt/Ctrl key hints. Targeted validation passed: `cargo fmt --check` and `cargo test -p oppi-shell`.
- 2026-05-03: Made double Ctrl+C exit the native/raw shell by routing the second consecutive Ctrl+C through the same `/exit` command path. The first Ctrl+C still interrupts or clears, but slash palettes and overlays now arm the second Ctrl+C before closing so two presses reliably turn OPPi off. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-shell`, and `cargo check -p oppi-shell`.
- 2026-05-04: Replaced the native `/login subscription codex` mock/delegation with a real ChatGPT/Codex OAuth flow. The shell opens the browser, listens on the local callback, stores redacted OAuth credentials under the protected Pi/OPPi auth store, configures an `openai-codex` direct provider, and the Rust provider reads/refreshes that auth store to call ChatGPT's Codex responses endpoint with redacted diagnostics. Targeted validation passed: `cargo fmt --check`, `cargo test -p oppi-core -p oppi-shell`, `cargo test -p oppi-protocol`, `cargo build -p oppi-server -p oppi-shell`, and a no-live Codex provider validation smoke with a fake auth store.
