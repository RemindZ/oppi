# @oppiai/native

Rust-first OPPi preview package. It installs side-by-side with the stable Pi-backed package:

```bash
npm install -g @oppiai/cli      # stable legacy package; installs `oppi`
npm install -g @oppiai/native   # Rust-first preview; installs `oppi-native` and `oppi-rs`
```

`@oppiai/native` intentionally does **not** claim the `oppi` binary. The `oppi` bin stays owned by `@oppiai/cli` until an explicit default-promotion/package handoff decision is made.

## Commands

```bash
oppi-native --version
oppi-native doctor --json
oppi-native smoke --mock --json
oppi-native                 # launches the retained Rust TUI preview
oppi-native --mock          # launches the retained Rust TUI with the mock provider
oppi-native --no-tui --mock # line-mode fallback for pipes/debugging
oppi-native server --stdio  # runs the bundled server over stdio
```

`oppi-rs` is an alias for `oppi-native`.

## Binary resolution

Normal npm installs should not require users to build Rust locally. Published tarballs include platform binaries under:

```text
bin/<platform>-<arch>/oppi-shell[.exe]
bin/<platform>-<arch>/oppi-server[.exe]
```

The launcher resolves binaries in this order:

1. explicit env overrides: `OPPI_NATIVE_SHELL_BIN` / `OPPI_NATIVE_SERVER_BIN` (or legacy `OPPI_SHELL_BIN` / `OPPI_SERVER_BIN`)
2. `OPPI_NATIVE_BIN_DIR`
3. package-bundled `bin/<platform>-<arch>/` or `prebuilds/<platform>-<arch>/`
4. separately installed platform packages such as `@oppiai/native-win32-x64` if present
5. monorepo development builds under `target/debug` or `target/release`

For local development before packaging binaries:

```powershell
.\scripts\rust-dev-startup.ps1              # build and open retained Rust TUI preview
.\scripts\rust-dev-startup.ps1 --pi-ui      # build Rust, then open stable OPPi/Pi UI with Rust mirroring
.\scripts\rust-dev-startup.ps1 --smoke      # build and run mock native smoke
.\scripts\rust-dev-startup.ps1 --no-build   # reuse existing builds
```

The retained Rust TUI now uses the same core rendering approach as Pi: raw terminal input, synchronized output, differential redraws, themed transcript/status footer, spinner, editor, docked panels, a five-row slash autocomplete below the editor, `/settings` panels anchored to the input area, Ctrl+L/Ctrl+P model shortcuts, and native picker/subpanel overlays for sessions, models, theme, permissions, provider, login, and memory. It is still a preview and does not yet have every mature Pi workflow affordance; use `--pi-ui` when you need the stable OPPi/Pi UI.

Provider auth:

- `/login subscription codex` opens browser OAuth for ChatGPT/Codex, stores tokens in the protected OPPi/Pi `auth.json`, and configures the native `openai-codex` provider without printing raw tokens.
- `/login api openai env <ENV>` configures an OpenAI-compatible API provider by env-reference only.
- `/login subscription claude` uses the explicit Meridian bridge flow; installs/starts are never hidden.

Manual equivalent:

```bash
cargo build -p oppi-server -p oppi-shell
pnpm --filter @oppiai/native build
node packages/native/dist/main.js doctor
node packages/native/dist/main.js smoke --mock --json
```

For publish/pack preparation, `pnpm --filter @oppiai/native build:binaries` builds release binaries and copies them into the package `bin/` directory. The package has no `postinstall` compile step.

## Relationship to other packages

- `@oppiai/cli` remains the stable Pi-backed `oppi` package.
- `@oppiai/native` is the Rust-first preview launcher.
- `@oppiai/natives` is a separate optional Node-loadable native-helper/probe package, not the end-user Rust shell launcher.
