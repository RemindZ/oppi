# Native TUI redesign bundle

Generated: 2026-05-04T23:09:56.434148+00:00

Purpose: hand a designer/implementer the files most relevant to redesigning the Rust-native OPPi TUI while comparing against the current stable Pi/OPPi UI.

## Included repo files
- `docs/native-tui-style-and-rendering-brief.md` — ok
- `README.md` — ok
- `packages/native/README.md` — ok
- `docs/runtime-jsonrpc.md` — ok
- `.oppi-plans/50-standalone-oppi-finish-line.md` — ok
- `crates/oppi-shell/src/tui.rs` — ok
- `crates/oppi-shell/src/main.rs` — ok
- `packages/pi-package/extensions/docked-ui.ts` — ok
- `packages/pi-package/extensions/effort.ts` — ok
- `packages/pi-package/extensions/memory.ts` — ok
- `packages/pi-package/extensions/permissions.ts` — ok
- `packages/pi-package/extensions/suggest-next.ts` — ok
- `packages/pi-package/extensions/themes.ts` — ok
- `packages/pi-package/extensions/todo-write.ts` — ok
- `packages/pi-package/extensions/usage.ts` — ok
- `packages/pi-package/themes/oppi-cyan.json` — ok
- `packages/pi-package/themes/oppi-cyan-light.json` — ok

## Included Pi reference files (MIT upstream runtime)

- `pi-reference/docs/tui.md` — ok
- `pi-reference/docs/themes.md` — ok
- `pi-reference/docs/keybindings.md` — ok
- `pi-reference/dist/modes/interactive/interactive-mode.js` — ok
- `pi-reference/dist/modes/interactive/components/assistant-message.js` — ok
- `pi-reference/dist/modes/interactive/components/bordered-loader.js` — ok
- `pi-reference/dist/modes/interactive/components/custom-message.js` — ok
- `pi-reference/dist/modes/interactive/components/footer.js` — ok
- `pi-reference/dist/modes/interactive/components/login-dialog.js` — ok
- `pi-reference/dist/modes/interactive/components/tool-execution.js` — ok
- `pi-reference/dist/modes/interactive/components/user-message.js` — ok
- `pi-reference/dist/modes/interactive/theme/dark.json` — ok
- `pi-reference/dist/modes/interactive/theme/light.json` — ok

## Notes

- This is a zip artifact only; it does not change runtime code.
- Do not treat native TUI as parity until the gates in `docs/native-tui-style-and-rendering-brief.md` pass.
